// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.

import axios from 'axios';

export type MemoryIndex = {
  id: string;
  title: string;
  snippet: string;
  score: number;
  type?: string;
  project?: string;
  created_at?: string;
};

export type Trial = {
  run_id?: string;
  trial_number: number;
  params: Record<string, number>;
  value: number | null;
  metrics?: Record<string, unknown>;
  state: string;
  datetime: string;
};

export type PolicyParams = {
  vector_weight: number;
  top_k: number;
  compression_threshold: number;
  salience_cutoff: number;
  episodic_retention: number;
};

// Vite exposes env variables prefixed with VITE_. When unset, fall back to the
// relative `/api` path which Vite dev server proxies to the FastAPI backend.
const apiBaseUrl = import.meta.env.VITE_API_URL?.trim() || '/api';

export const api = axios.create({
  baseURL: apiBaseUrl,
  timeout: 30000,
});

export async function fetchMemories(query: string, limit = 20) {
  const path = query.trim() ? '/memories/search' : '/memories/list';
  const params = query.trim() ? { q: query, limit } : { limit };
  const response = await api.get(path, { params });
  return response.data.memories as MemoryIndex[];
}

export async function fetchEvolutionHistory() {
  const response = await api.get('/evolution/history');
  return response.data.trials as Trial[];
}

export async function fetchCurrentParams() {
  const response = await api.get('/evolution/current');
  return response.data.params as PolicyParams;
}
