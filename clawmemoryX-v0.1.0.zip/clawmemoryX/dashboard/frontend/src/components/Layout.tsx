// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.

import { Link, NavLink, Outlet } from 'react-router-dom';

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `rounded-lg px-3 py-2 text-sm font-medium ${isActive ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-100'}`;

export default function Layout() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <Link to="/" className="text-xl font-semibold tracking-tight">
            ClawMemory-X
          </Link>
          <nav className="flex items-center gap-2">
            <NavLink to="/" className={linkClass}>Memories</NavLink>
            <NavLink to="/evolution" className={linkClass}>Evolution</NavLink>
            <NavLink to="/about" className={linkClass}>About / Source</NavLink>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-6 py-6">
        <Outlet />
      </main>
      <footer className="mx-auto flex max-w-7xl items-center justify-between border-t border-slate-200 px-6 py-4 text-sm text-slate-500">
        <span>AGPL-3.0 · Built on claude-mem</span>
        <Link to="/about" className="font-medium text-blue-600 underline">Source</Link>
      </footer>
    </div>
  );
}
