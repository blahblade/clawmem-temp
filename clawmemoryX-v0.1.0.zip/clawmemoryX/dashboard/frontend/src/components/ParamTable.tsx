// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.

import type { PolicyParams } from '../api/client';

export default function ParamTable({ params }: { params: PolicyParams | null }) {
  if (!params) {
    return <div className="card p-4 text-sm text-slate-500">Loading current params...</div>;
  }
  return (
    <div className="card overflow-hidden">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-100 text-slate-600">
          <tr><th className="px-4 py-2">Parameter</th><th className="px-4 py-2">Value</th></tr>
        </thead>
        <tbody>
          {Object.entries(params).map(([key, value]) => (
            <tr key={key} className="border-t border-slate-100">
              <td className="px-4 py-2 font-medium">{key}</td>
              <td className="px-4 py-2">{typeof value === 'number' ? value.toFixed(key.includes('weight') || key.includes('cutoff') ? 3 : 0) : value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
