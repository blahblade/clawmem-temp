// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.

import { useState } from 'react';
import type { MemoryIndex } from '../api/client';

export default function MemoryCard({ memory }: { memory: MemoryIndex }) {
  const [expanded, setExpanded] = useState(false);
  const preview = memory.snippet || memory.title || '(empty memory)';
  return (
    <article className="card p-4">
      <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-slate-500">
        <span className="rounded-full bg-slate-100 px-2 py-1">#{memory.id}</span>
        {memory.type && <span className="rounded-full bg-slate-100 px-2 py-1">{memory.type}</span>}
        <span className="rounded-full bg-slate-100 px-2 py-1">score {Number(memory.score || 0).toFixed(3)}</span>
        {memory.created_at && <span>{memory.created_at}</span>}
      </div>
      <h2 className="text-base font-semibold text-slate-900">{memory.title || 'Untitled memory'}</h2>
      <p className={`mt-2 text-sm leading-6 text-slate-700 ${expanded ? '' : 'line-clamp-3'}`}>{preview}</p>
      <button className="mt-3 text-sm font-medium text-blue-600" onClick={() => setExpanded(!expanded)}>
        {expanded ? 'Collapse' : 'Expand'}
      </button>
    </article>
  );
}
