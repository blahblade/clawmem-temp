// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.

export default function About() {
  const sourceUrl = import.meta.env.VITE_CLAWMEM_SOURCE_URL || 'https://github.com/SJTU/clawmemoryX';
  return (
    <div className="card max-w-3xl p-6">
      <h1 className="text-2xl font-semibold">About ClawMemory-X</h1>
      <p className="mt-4 text-slate-700">
        ClawMemory-X is a self-evolving long-term memory system for OpenClaw agents, built for the SJTU OpenClaw Innovation Contest 2026.
      </p>

      <h2 className="mt-6 text-xl font-semibold">License</h2>
      <p className="mt-2 text-slate-700">Licensed under GNU Affero General Public License v3.0.</p>

      <h2 className="mt-6 text-xl font-semibold">Source Code</h2>
      <p className="mt-2">
        <a href={sourceUrl} className="text-blue-600 underline" target="_blank" rel="noreferrer">{sourceUrl}</a>
      </p>
      <p className="mt-2 text-sm text-slate-600">
        AGPL-3.0 §13 requires source-code access when this network service is deployed for remote users.
      </p>

      <h2 className="mt-6 text-xl font-semibold">Built On</h2>
      <p className="mt-2 text-slate-700">
        Powered by <a href="https://github.com/thedotmack/claude-mem" className="text-blue-600 underline" target="_blank" rel="noreferrer">claude-mem (AGPL-3.0)</a> by Alex Newman.
      </p>
    </div>
  );
}
