// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.

import { FormEvent, useEffect, useState } from 'react';
import { fetchMemories, type MemoryIndex } from '../api/client';
import MemoryCard from '../components/MemoryCard';

export default function MemoryBrowser() {
  const [query, setQuery] = useState('');
  const [memories, setMemories] = useState<MemoryIndex[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = async (q = query) => {
    setLoading(true);
    setError(null);
    try {
      setMemories(await fetchMemories(q, 50));
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(''); }, []);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    void load(query);
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold">Memory Browser</h1>
        <p className="mt-1 text-sm text-slate-600">Search claude-mem observations through the ClawMemory-X policy layer.</p>
      </div>

      <form onSubmit={submit} className="card mb-6 flex gap-3 p-4">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search memories, e.g. FastAPI / ACME / vector_weight..."
          className="flex-1 rounded-lg border border-slate-300 px-3 py-2 outline-none focus:border-blue-500"
        />
        <button className="rounded-lg bg-slate-900 px-4 py-2 text-white" type="submit">Search</button>
      </form>

      {loading && <div className="card p-4 text-sm text-slate-500">Loading...</div>}
      {error && <div className="card border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
      {!loading && !error && memories.length === 0 && (
        <div className="card p-6 text-sm text-slate-600">
          No memories returned. If claude-mem is not running, start it on port 37777 or use the benchmark/evolution demo mode.
        </div>
      )}
      <div className="grid gap-4 lg:grid-cols-2">
        {memories.map((memory) => <MemoryCard key={memory.id} memory={memory} />)}
      </div>
    </div>
  );
}
