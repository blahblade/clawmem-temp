// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.

import { useEffect, useMemo, useState } from 'react';
import Plot from 'react-plotly.js';
import { api, fetchCurrentParams, fetchEvolutionHistory, type PolicyParams, type Trial } from '../api/client';
import ParamTable from '../components/ParamTable';

const PARAMS = ['vector_weight', 'top_k', 'compression_threshold', 'salience_cutoff', 'episodic_retention'];

export default function EvolutionChart() {
  const [trials, setTrials] = useState<Trial[]>([]);
  const [currentParams, setCurrentParams] = useState<PolicyParams | null>(null);
  const [selectedParam, setSelectedParam] = useState('vector_weight');
  const [running, setRunning] = useState(false);
  const [mode, setMode] = useState<'auto' | 'offline' | 'live'>('offline');
  const [nTrials, setNTrials] = useState(10);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const load = async () => {
    const [history, params] = await Promise.all([fetchEvolutionHistory(), fetchCurrentParams()]);
    setTrials(history.filter((trial) => trial.value !== null));
    setCurrentParams(params);
  };

  useEffect(() => { void load(); }, []);

  const bestSoFar = useMemo(() => {
    const acc: number[] = [];
    for (const trial of trials) {
      const previous = acc.length > 0 ? acc[acc.length - 1] : Number.NEGATIVE_INFINITY;
      acc.push(Math.max(previous, Number(trial.value ?? 0)));
    }
    return acc;
  }, [trials]);

  const triggerEvolution = async () => {
    setRunning(true);
    setErrorMessage(null);
    try {
      await api.post('/evolution/trigger', null, {
        params: { n_trials: nTrials, mode, background: false },
      });
      await load();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setRunning(false);
    }
  };

  // Use global trial index on the x-axis so points always line up with integers.
  // Original run_id + per-run trial_number are surfaced through customdata / tooltip.
  const trialIndex = trials.map((_trial, index) => index);
  const objectiveValues = trials.map((trial) => Number(trial.value ?? 0));
  const paramValues = trials.map((trial) => Number(trial.params[selectedParam] ?? 0));
  const customLabels = trials.map(
    (trial) => `${trial.run_id || 'run'} · trial ${trial.trial_number}`,
  );

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Evolution Trajectory</h1>
          <p className="mt-1 text-sm text-slate-600">Objective value, best-so-far curve, and policy parameter trajectories.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={mode}
            onChange={(event) => setMode(event.target.value as typeof mode)}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
            title="Evaluation mode"
          >
            <option value="offline">Offline simulator</option>
            <option value="auto">Auto (live if available)</option>
            <option value="live">Live claude-mem</option>
          </select>
          <input
            type="number"
            min={1}
            max={100}
            value={nTrials}
            onChange={(event) => setNTrials(Math.max(1, Math.min(100, Number(event.target.value) || 10)))}
            className="w-20 rounded-lg border border-slate-300 px-3 py-2 text-sm"
            title="Number of trials"
          />
          <button
            onClick={triggerEvolution}
            disabled={running}
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
          >
            {running ? 'Running...' : `Trigger ${nTrials} ${mode} trials`}
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="card mb-4 border-red-200 bg-red-50 p-3 text-sm text-red-700">
          Evolution failed: {errorMessage}
        </div>
      )}

      <div className="mb-6 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="card p-4">
          <Plot
            data={[
              {
                x: trialIndex,
                y: objectiveValues,
                type: 'scatter',
                mode: 'markers',
                name: 'Trial',
                text: customLabels,
                hovertemplate: '%{text}<br>Score: %{y:.4f}<extra></extra>',
              },
              {
                x: trialIndex,
                y: bestSoFar,
                type: 'scatter',
                mode: 'lines',
                name: 'Best so far',
                line: { width: 3 },
                hovertemplate: 'Best so far: %{y:.4f}<extra></extra>',
              },
            ] as any}
            layout={{
              title: 'Objective Value Over Trials',
              xaxis: { title: 'Trial index (global)' },
              yaxis: { title: 'Score' },
              autosize: true,
            }}
            useResizeHandler
            style={{ width: '100%', height: '420px' }}
          />
        </div>
        <ParamTable params={currentParams} />
      </div>

      <div className="card mb-6 p-4">
        <div className="mb-3 flex items-center gap-3">
          <label className="text-sm font-medium">Parameter</label>
          <select value={selectedParam} onChange={(event) => setSelectedParam(event.target.value)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            {PARAMS.map((param) => <option key={param} value={param}>{param}</option>)}
          </select>
        </div>
        <Plot
          data={[
            {
              x: trialIndex,
              y: paramValues,
              type: 'scatter',
              mode: 'lines+markers',
              name: selectedParam,
              text: customLabels,
              hovertemplate: '%{text}<br>' + selectedParam + ': %{y}<extra></extra>',
            },
          ] as any}
          layout={{ title: `${selectedParam} evolution`, xaxis: { title: 'Trial index (global)' }, yaxis: { title: selectedParam }, autosize: true }}
          useResizeHandler
          style={{ width: '100%', height: '360px' }}
        />
      </div>

      <div className="card p-4">
        <Plot
          data={[{
            type: 'parcoords',
            line: { color: objectiveValues, showscale: true },
            dimensions: PARAMS.concat(['objective']).map((param) => ({
              label: param,
              values: param === 'objective' ? objectiveValues : trials.map((trial) => Number(trial.params[param] ?? 0)),
            })),
          }] as any}
          layout={{ title: 'Parallel Coordinates: Params + Objective', autosize: true }}
          useResizeHandler
          style={{ width: '100%', height: '420px' }}
        />
      </div>
    </div>
  );
}
