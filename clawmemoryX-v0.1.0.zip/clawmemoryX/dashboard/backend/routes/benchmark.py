# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Benchmark dashboard routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from benchmark.evaluate import run_benchmark
from policy.current import get_current_params

router = APIRouter()


@router.get("/run")
async def run_current(mode: str | None = None) -> dict[str, Any]:
    params = get_current_params()
    metrics = await run_benchmark(params, mode=mode)
    return {"params": params, "metrics": metrics}
