# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Policy evolution dashboard routes."""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, BackgroundTasks

from policy.current import get_current_params
from policy.evolver import HISTORY_PATH, evolve

router = APIRouter()


@router.get("/history")
async def get_history() -> dict[str, Any]:
    if not HISTORY_PATH.exists():
        return {"trials": []}
    trials = [json.loads(line) for line in HISTORY_PATH.read_text(encoding="utf-8").splitlines() if line.strip()]
    return {"trials": trials}


@router.get("/current")
async def current_params() -> dict[str, Any]:
    return {"params": get_current_params()}


@router.post("/trigger")
async def trigger_evolution(
    background_tasks: BackgroundTasks,
    n_trials: int = 10,
    apply_best: bool = True,
    mode: str | None = None,
    background: bool = True,
) -> dict[str, Any]:
    if background:
        background_tasks.add_task(evolve, n_trials=n_trials, apply_best=apply_best, mode=mode)
        return {"status": "scheduled", "n_trials": n_trials, "mode": mode or "auto"}
    result = await evolve(n_trials=n_trials, apply_best=apply_best, mode=mode)
    return result
