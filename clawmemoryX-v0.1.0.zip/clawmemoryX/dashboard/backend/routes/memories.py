# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Memory browsing and search routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException

from integration.claude_mem_client import ClaudeMemClient

router = APIRouter()


@router.get("/list")
async def list_memories(project: str = "openclaw", limit: int = 50) -> dict[str, Any]:
    """List recent memory index entries.

    claude-mem does not expose a dedicated "list all" endpoint, so we issue a
    broad search query. When the worker is unavailable we still return a valid
    payload so the dashboard stays usable.
    """

    async with ClaudeMemClient() as client:
        if not await client.health():
            return {"memories": [], "backend": "unavailable"}
        # Broad query designed to surface recent entries; individual backends
        # may interpret an empty string differently, so we use a neutral token.
        results = await client.search(query="memory", limit=limit, project=project)
        return {"memories": [item.to_dict() for item in results], "backend": "claude-mem"}


@router.get("/search")
async def search_memories(q: str, project: str = "openclaw", limit: int = 20) -> dict[str, Any]:
    async with ClaudeMemClient() as client:
        if not await client.health():
            return {"memories": [], "backend": "unavailable"}
        results = await client.search(query=q, limit=limit, project=project)
        return {"memories": [item.to_dict() for item in results], "backend": "claude-mem"}


@router.get("/{observation_id}")
async def get_memory(observation_id: str) -> dict[str, Any]:
    async with ClaudeMemClient() as client:
        results = await client.get_observations(ids=[observation_id])
        if not results:
            raise HTTPException(status_code=404, detail="not found")
        return results[0]
