# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""FastAPI app for ClawMemory-X dashboard."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from dashboard.backend.config import get_settings
from dashboard.backend.routes import benchmark, evolution, memories

app = FastAPI(title="ClawMemory-X Dashboard API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(memories.router, prefix="/api/memories", tags=["memories"])
app.include_router(evolution.router, prefix="/api/evolution", tags=["evolution"])
app.include_router(benchmark.router, prefix="/api/benchmark", tags=["benchmark"])


@app.get("/api/health")
async def health() -> dict[str, str]:
    settings = get_settings()
    return {"status": "ok", "service": "clawmemoryX-dashboard", "project": settings.project}


@app.get("/api/about")
async def about() -> dict[str, str]:
    settings = get_settings()
    return {
        "name": "ClawMemory-X",
        "license": "AGPL-3.0",
        "source_url": settings.source_url,
        "built_on": "claude-mem",
        "claude_mem_url": "https://github.com/thedotmack/claude-mem",
    }


_FRONTEND_DIST = Path(__file__).resolve().parents[1] / "frontend" / "dist"
if _FRONTEND_DIST.exists():
    app.mount("/assets", StaticFiles(directory=_FRONTEND_DIST / "assets"), name="assets")


@app.get("/")
async def index():
    index_html = _FRONTEND_DIST / "index.html"
    if index_html.exists():
        return FileResponse(index_html)
    return JSONResponse({"message": "ClawMemory-X API is running. Start the Vite frontend for the UI."})
