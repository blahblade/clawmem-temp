# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Dashboard backend settings."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    project: str = os.environ.get("CLAWMEM_PROJECT", "openclaw")
    claude_mem_url: str = os.environ.get("CLAWMEM_CLAUDE_MEM_URL", "http://localhost:37777")
    source_url: str = os.environ.get("CLAWMEM_SOURCE_URL", "https://github.com/SJTU/clawmemoryX")
    benchmark_mode: str = os.environ.get("CLAWMEM_BENCHMARK_MODE", "auto")


def get_settings() -> Settings:
    return Settings()
