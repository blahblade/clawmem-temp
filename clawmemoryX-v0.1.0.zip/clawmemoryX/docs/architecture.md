# ClawMemory-X Architecture

> Status: v0.1.0 · 2026-04
> Audience: judges, contributors, integrators

ClawMemory-X is an OpenClaw-compatible memory strategy layer built on top of
[claude-mem](https://github.com/thedotmack/claude-mem) (AGPL-3.0). This document
explains how the pieces fit together, what guarantees we provide, and where the
boundaries are.

## 1. System context

```mermaid
flowchart TB
    User["User<br/>(WhatsApp / Telegram / CLI)"]
    OC["OpenClaw Gateway"]
    Skill["ClawMemory-X Skill<br/>(memory_read / write / compress)"]
    Policy["Policy Engine<br/>(Optuna TPE)"]
    Salience["Salience Scorer<br/>(DeepSeek + heuristic)"]
    Bench["Benchmark Runner<br/>(15 cases, live + offline)"]
    Dash["Dashboard<br/>(FastAPI + React)"]
    Worker["claude-mem Worker<br/>(localhost:37777)"]
    DB[("SQLite<br/>+ Chroma")]

    User -->|messages| OC
    OC -->|tool calls| Skill
    Skill -->|θ lookup| Policy
    Skill -->|score msgs| Salience
    Skill -.HTTP.-> Worker
    Bench -.HTTP.-> Worker
    Worker --> DB
    Dash -.HTTP.-> Worker
    Dash -->|read θ + history| Policy
    Dash -->|trigger| Bench
    Policy -->|run| Bench
    Bench -->|metrics| Policy
```

Everything inside the dashed border is **ClawMemory-X code** (new, licensed
AGPL-3.0 by us). claude-mem is invoked only over HTTP — no source code is
imported, modified, or re-packaged.

## 2. Component map

| Package | Responsibility | Key files |
|---|---|---|
| `skill/` | OpenClaw skill manifest + three tools + five lifecycle hooks | `skill.json`, `hooks.py`, `memory_{read,write,compress}.py` |
| `integration/` | HTTP client and SSE subscriber for claude-mem | `claude_mem_client.py`, `sse_subscriber.py` |
| `salience/` | Importance scoring with LLM + heuristic fallback | `scorer.py`, `prompts.py` |
| `policy/` | Evolvable parameter space, Optuna optimizer, scheduler | `params.py`, `evolver.py`, `objective.py`, `current.py`, `scheduler.py` |
| `benchmark/` | 15-case dataset + live and offline runners | `dataset.jsonl`, `evaluate.py`, `replay.py`, `metrics.py` |
| `dashboard/backend/` | FastAPI service that fronts the memory, policy, and benchmark APIs | `main.py`, `routes/` |
| `dashboard/frontend/` | React + Plotly UI with Memory Browser, Evolution Chart, About pages | `src/pages/`, `src/components/` |
| `scripts/` | CLI entry points + demo orchestration + compliance checks | `demo.sh`, `smoke_test.sh`, `check_compliance.sh` |

## 3. Lifecycle hook flow

```mermaid
sequenceDiagram
    autonumber
    participant OC as OpenClaw
    participant Skill as ClawMemory-X
    participant CM as claude-mem
    participant Pol as Policy

    Note over OC,Pol: Session start
    OC->>Skill: before_prompt_build(ctx)
    Skill->>CM: POST /api/sessions/init
    CM-->>Skill: session_id
    Skill->>CM: GET /api/context/inject?projects=…
    CM-->>Skill: markdown timeline
    Skill-->>OC: { appendSystemContext: md }

    Note over OC,Pol: Each turn
    OC->>Skill: on_turn_end(ctx, estimated_tokens)
    Skill->>Pol: get_current_params()
    Pol-->>Skill: θ
    alt estimated_tokens ≥ θ.compression_threshold
        Skill->>Skill: memory_compress(messages)
        Skill->>CM: POST /api/sessions/observations (episodic_summary)
    end

    Note over OC,Pol: Tool result
    OC->>Skill: tool_result_persist(ctx)
    Skill->>CM: POST /api/sessions/observations (tool_result)

    Note over OC,Pol: Session end
    OC->>Skill: on_session_end(ctx)
    Skill->>CM: POST /api/sessions/complete
```

## 4. HTTP boundary with claude-mem

ClawMemory-X communicates with claude-mem exclusively through these endpoints,
all local:

| Endpoint | Method | Purpose |
|---|---|---|
| `/health` | GET | readiness check (degrade gracefully if 4xx/5xx) |
| `/api/sessions/init` | POST | create a content session, get `session_id` |
| `/api/sessions/observations` | POST | record an observation or episodic summary |
| `/api/sessions/summarize` | POST | trigger a session-level summary |
| `/api/sessions/complete` | POST | close a session |
| `/api/context/inject?projects=<p>` | GET | return ready-to-inject system-prompt markdown |
| `/api/search` | POST | Progressive Disclosure layer 1: index entries |
| `/api/observation/{id}` | GET | single observation lookup |
| `/api/observations/batch` | POST | Progressive Disclosure layer 2: batch details |
| `/stream` | GET (SSE) | real-time `new_observation` events |

Every client method swallows network and 404 errors and returns safe defaults
(empty lists, empty markdown, `False` for health). This is deliberate — we do
not want a misbehaving memory backend to crash OpenClaw.

## 5. Policy evolution

### 5.1 Parameter space

Five evolvable knobs, all sanitized to declared ranges on every read/write:

| Name | Range | Default | Meaning |
|---|---|---|---|
| `vector_weight` | `0.0 – 1.0` | `0.7` | BM25 vs semantic search weighting (1-vw = BM25 weight) |
| `top_k` | `3 – 20` | `10` | Observations returned per query |
| `compression_threshold` | `2000 – 16000` (step 1000) | `8000` | Token threshold that triggers `memory_compress` |
| `salience_cutoff` | `0.1 – 0.5` | `0.3` | Messages below this score are compressed instead of kept verbatim |
| `episodic_retention` | `7 – 90` | `30` | Days to keep episodic summaries before decay |

### 5.2 Objective function

```
J(θ) = 0.5 · recall_at_k + 0.3 · task_success_rate − 0.2 · (token_cost / max_token_cost)
```

Rationale: recall is most important because a memory system that forgets is
worthless; task success captures end-to-end usefulness; token cost is a soft
budget constraint, deliberately weighted lower so recall is never sacrificed
for a small token saving.

### 5.3 Optimization

```mermaid
flowchart LR
    A["seed θ₀ = DEFAULT_PARAMS"] --> B["Optuna TPE sampler"]
    B -->|suggest θ| C["run_benchmark(θ)"]
    C --> D["J(θ) score"]
    D -->|tell| B
    B -->|n trials| E{Best θ*}
    E -->|apply_best=True| F["policy/data/current.json"]
    C --> G["policy/data/history.jsonl"]
    E --> G
```

Optuna is optional: if the import fails at runtime (for example on a minimal
container), `evolver._evolve_random` takes over and performs deterministic
uniform sampling. The rest of the pipeline is agnostic to which sampler ran.

### 5.4 Benchmark modes

| Mode | When to use | What it does |
|---|---|---|
| `live` | Final submission, grading, real accuracy numbers | Replays each case into an isolated project on a real claude-mem worker and measures recall with the real search stack |
| `offline` | CI, demos, laptops without claude-mem installed | Deterministic simulator that mimics the search pipeline and applies a `_policy_quality` multiplier tuned so that `vector_weight ≈ 0.58` is the optimum — this is the story the Evolution Chart tells |
| `auto` | Default | Uses `live` if `/health` is reachable, otherwise falls back to `offline` |

The offline simulator is **not a shortcut or a cheat** — it is how we keep the
dashboard functional when no worker is running (first-time developers, CI
jobs, and the demo fallback path). Final numbers quoted in the proposal come
from the live mode.

## 6. Storage layout

```text
policy/data/
├── current.json          # active θ, atomically written (.tmp + replace)
└── history.jsonl         # every trial from every run_id, append-only
```

History records look like this:

```json
{
  "run_id": "evolve-20260423T181204Z",
  "trial_number": 17,
  "params": {"vector_weight": 0.58, "top_k": 12, ...},
  "value": 0.74,
  "metrics": {"recall_at_k": 0.90, "task_success_rate": 0.95, ...},
  "state": "COMPLETE",
  "datetime": "2026-04-23T18:14:47+00:00"
}
```

## 7. Failure modes and degradation

| Scenario | Behavior |
|---|---|
| claude-mem worker down | `memory_read` returns `{memories: [], error: "memory_backend_unavailable"}`; dashboard shows empty state with a hint; benchmark falls back to offline |
| DeepSeek API down or key missing | Salience scorer returns heuristic scores; cache hits are unchanged |
| Optuna import fails | `_evolve_random` provides deterministic random search |
| `tiktoken` not installed | `count_tokens` falls back to whitespace split |
| `policy/data/current.json` malformed | `get_current_params` reinitializes with defaults |
| Concurrent `set_current_params` | Protected by `RLock` + atomic `.tmp`/`replace` |

None of these paths silently corrupt data; every degradation is logged.

## 8. What we deliberately chose **not** to do

- **No RL** — the proposal mentioned REINFORCE; we switched to Optuna TPE
  because it converges in tens of trials instead of thousands, has a built-in
  visualizer, and produces an auditable trace. RL is left as future work.
- **No fork of claude-mem** — HTTP boundary only. AGPL-3.0 is respected and
  the project is upgradeable whenever claude-mem releases a new version.
- **No custom vector database** — we defer to claude-mem's SQLite + Chroma
  stack. We focus on the *strategy* on top, not the storage below.
- **No authentication on the dashboard** — the dashboard binds to loopback by
  default and is meant for a single-user demo. Production deployments should
  front it with a reverse proxy.

## 9. Roadmap hooks

The architecture leaves room for three future directions:

- **Online policy updates.** `policy/scheduler.py` already runs a periodic
  evolution loop; plug in a smaller `n_trials` and a sliding benchmark window
  to get continuous improvement.
- **Per-agent policies.** `policy/current.json` is global today. The sanitize
  layer already supports partial parameter dicts, so per-agent-ID overrides
  are straightforward.
- **RL on top of Optuna.** The history.jsonl log is rich enough to train a
  contextual-bandit policy that picks `θ` from the last N successful trials
  conditional on session metadata.
