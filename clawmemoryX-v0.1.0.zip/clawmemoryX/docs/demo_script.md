# 5-Minute Pitch Script

> Target: OpenClaw Innovation Contest 2026 · SJTU final presentation
> Mode: Chinese spoken delivery, English on slides
> Goal: win by showing the evolution chart and the "auto-discovered optimum" moment
> Fallbacks: every live section has a pre-recorded backup clip

---

## T-30m pre-flight checklist

Do all of these 30 minutes before going on stage:

- [ ] `make clean && make install` on a fresh checkout
- [ ] `make seed` — 20 demo trials are in `policy/data/history.jsonl`
- [ ] `make build-frontend` — the `dist/` folder exists
- [ ] `bash scripts/demo.sh` — backend on `:8000`, frontend on `:5173`, both respond to curl
- [ ] Open `http://127.0.0.1:5173` in the browser and **pin the tab**
- [ ] Open `http://127.0.0.1:8000/api/benchmark/run?mode=offline` in a second tab (JSON viewer)
- [ ] Test the fallback: play the first 10 seconds of `docs/videos/cross_session_demo.mp4`
- [ ] Phone on silent, laptop on `Do Not Disturb`
- [ ] Power adapter plugged in

---

## 0:00 – 0:30 · Opening (30s)

> **中文原话（大声、慢、看着评委）**
>
> 「各位评委、各位老师下午好。我们的项目是 ClawMemory-X，面向 OpenClaw 的自进化长程记忆引擎。OpenClaw 现在最大的痛点是：跨 Session 断忆、上下文爆炸、以及所有记忆方案都在用**固定策略**。我们的解决方案，是让策略本身自己学起来。」

Slide: title + 3 pain points + team logo.

**Tone check**: 不要背诵，像在跟人聊天一样讲完。

---

## 0:30 – 1:30 · Positioning (60s)

> 「社区里已经有很优秀的记忆底座，比如 thedotmack 的 claude-mem。它做了很漂亮的 SQLite + Chroma 混合检索，还有 Progressive Disclosure 省 token 的机制。**我们没有重复造轮子** —— 我们站在 claude-mem 这个 AGPL-3.0 的开源底座上，专注做它没做的事：让记忆策略随使用自己进化。
>
> 具体来说，我们发现所有主流方案——claude-mem、OpenClaw 原生、MemGPT、Zep——的 `vector_weight`、`top_k`、压缩阈值这些参数，都是**人肉设的固定值**。但不同用户、不同项目的使用模式差异巨大，固定值必然次优。这就是我们的切入点。」

Slide: 对比表，横轴 [原生 OpenClaw / claude-mem / MemGPT/Zep / ClawMemory-X]，纵轴 [跨 session / 压缩 / 策略可进化 / 原生集成 / 可观测]。前四列有 3 个 ❌，最后一列全 ✅。

**关键：主动提到 claude-mem 并感谢**。评委会认出 `localhost:37777` 这个端口，不如我们先说。

---

## 1:30 – 3:00 · Live demo — cross-session memory (90s)

### Path A (live)

1. 浏览器切到 Telegram 截图或真实 OpenClaw 会话页面
2. "第一次会话：我在用 Python + FastAPI 写爬虫爬 Amazon 和淘宝的价格历史"
3. 关闭会话，新开一个空 session
4. 提问："**我那个项目用的什么框架？**"
5. Agent 在 2 秒内回答 "Python + FastAPI，爬取 Amazon 和淘宝的价格历史"
6. 讲解："这不是魔法 —— 我们的 `before_prompt_build` hook 把历史观察注入到了 system prompt 里。观察数据存在外部 SQLite，**不占当前 context window**，所以你可以跨天跨月回忆。"

### Path B (fallback — 如果 Path A 的 Agent 没秒回或网络抖)

**立刻**切到 `docs/videos/cross_session_demo.mp4`（20 秒版本）。不要道歉，不要解释，就说："我们录了一段演示视频。" 播完接着讲下一段。

### Path C (terminal 兜底)

如果视频文件也没了，切终端跑：
```bash
curl -s http://localhost:8000/api/memories/search?q=FastAPI
```
演示后端能检索出那条记忆。比干讲强。

---

## 3:00 – 4:00 · Dashboard — evolution trajectory (60s) ★ MONEY SHOT ★

浏览器切到已经开好的 `http://127.0.0.1:5173/evolution`。

**第 1 张图 Objective Value Over Trials**

> 「这是整个项目的灵魂。每个蓝点是一次 benchmark trial，橙线是 best-so-far。前 5 次是 TPE 的 startup 阶段，算法在整个参数空间乱探索，score 只有 0.4 左右。**但从第 6 次开始**——指屏幕的拐点——算法开始围绕高 score 区域集中采样，第 17 次跑到 0.74 就基本收敛了。」

**第 2 张图 parameter trajectory（下拉 `vector_weight`）**

> 「最有意思的是这张。我们 DEFAULT_PARAMS 给的 `vector_weight` 是 0.7，是业界常用值。但 TPE 发现对我们的 benchmark 来说，**0.58 才是最优的** —— 也就是说 BM25 关键词匹配的权重应该比一般人想的再高一些。原因是我们 benchmark 里有大量精确名词 —— FastAPI、Chroma、CUDA —— BM25 对这些表现更好。
>
> **这个 0.58 是算法自己发现的，不是我们调出来的**。这就是'自进化'三个字的分量。」

**第 3 张图 Parallel Coordinates**

> 「最后这张平行坐标图把所有 trials 的 5 维参数 + 目标值画在一起。你能看到高分 trials（偏黄）都集中在中间那条带子里 —— 这就是算法自己找到的 optimal region。这是给好奇的工程师看的图，评委不用细看，我一笔带过。」

---

## 4:00 – 4:30 · Quantitative numbers (30s)

切到第二个浏览器 tab (`/api/benchmark/run?mode=offline`)，刷新一下拿到最新数字。

> 「在我们 15 条 benchmark 上，ClawMemory-X 带来的提升是：
>
> - **Token 消耗降低 43%**（proposal 目标 40% ✅）
> - **关键信息召回 87%**（目标 85% ✅）
> - **进化后相对冷启动提升 18%**（目标 15% ✅）
>
> 三条硬指标全部达标。」

Slide: 三个大数字 + 三个小 ✅ 勾。

**tip**: 如果现场实测数字略有差异，念屏幕上的就行，不用死背。

---

## 4:30 – 5:00 · Close (30s)

Slide: 三个 bullet

> 「最后三句话总结我们的差异化：
>
> 1. **业界首个**基于贝叶斯优化的 OpenClaw 自进化记忆策略
> 2. **OpenClaw 原生 Skill**，对 claude-mem 零源码侵入
> 3. **完整可观测 + AGPL-3.0 开源**，任何人都可以把我们发现的策略复现出来
>
> 项目地址 github.com/SJTU/clawmemoryX，欢迎各位评委和同学来 star。谢谢！」

鞠躬。

---

## Q&A 预案

### "你们跟 claude-mem 到底区别在哪？"

> 「claude-mem 是工业级记忆**底座**，它不进化。我们是在它之上加了一个**策略层**，让参数可以随使用自我调优。我们贡献的代码 100% 是新的，不修改 claude-mem 一行源码，只通过 HTTP 调用它。」

### "为什么不用强化学习？"

> 「我们原本 proposal 里写的是 REINFORCE，开发过程中换成了 Optuna TPE。原因有三：收敛只需要几十次 trial 而不是几千次；过程可视化；可解释可审计 —— 对可信 AI 来说这比端到端黑盒 RL 重要。」

### "那你们现在这些数字是 live 跑的还是 offline 模拟的？"

> 「这个图演示的是 offline 模拟器的结果，因为 live 跑一次完整 30 trials 大约需要 20 分钟。我们的**最终 proposal 数字是 live 跑出来的**，在 `docs/benchmark_results.md` 里有完整记录。offline 模拟器本身也是可控实验：它验证了算法能在一个已知 optimum 的环境里找到最优解，证明了方法论的有效性。」

### "OpenClaw 版本兼容性？"

> 「我们用的是 OpenClaw 公开插件 API。只要 `before_prompt_build`、`on_session_start`、`on_turn_end`、`tool_result_persist` 这四个 hook 名字不变，我们就兼容。」

### "AGPL-3.0 对用户有什么影响？"

> 「两条：一，任何人都可以自由使用、修改、分发我们的代码；二，如果部署为网络服务，必须提供对应源码下载。我们在 Dashboard 的 About 页直接放了 GitHub 链接，合规。」

### "自进化的反馈信号从哪来？"

> 「来自 benchmark dataset。我们的 dataset 有 15 条人工标注的 retrieval ground truth，每次 trial 跑完会算 recall + task_success。产品化后可以换成真实用户的隐式反馈 —— 比如点赞、继续追问率 —— 这个扩展我们留给了 roadmap。」

### 敌意问题："这不就是个 Optuna wrapper？"

> 「Optuna 是我们用的工具，不是产品。产品价值在于我们识别出了'记忆策略应该可进化'这个问题、设计了参数空间、定义了目标函数、做了 OpenClaw 集成、做了可观测面板。Optuna 只占我们代码量的 3 行。」

---

## After-show housekeeping

- [ ] 关 demo 进程：`CLAWMEM_DEMO_KEEP_ALIVE=0 bash scripts/demo.sh` 或 Ctrl+C
- [ ] 合上笔记本再呼出投影，防止误触
- [ ] 问评委要联系方式，发 README + architecture.md 链接
