# API Reference

ClawMemory-X exposes two interfaces: the **Skill tools** that OpenClaw agents
call during a session, and the **Dashboard REST API** that the UI and external
scripts use.

---

## 1. Skill tools (OpenClaw)

These are the three tools declared in `skill/skill.json`. OpenClaw's planner
decides when to call them; no hard-coded invocation is needed.

### `memory_read`

Retrieve relevant memories for a natural-language query. Uses the current
policy's `top_k` unless overridden.

**Input**

| Field | Type | Required | Default |
|---|---|---|---|
| `query` | string | yes | — |
| `top_k` | integer \| null | no | from current policy |
| `project` | string | no | `"openclaw"` |

**Output**

```json
{
  "memories": [ { "id": "...", "content": "...", "type": "...", ... } ],
  "index": [ { "id": "...", "title": "...", "score": 0.87 } ],
  "params_used": { "vector_weight": 0.58, "top_k": 12, ... },
  "retrieved_count": 7
}
```

Error shape when the backend is unavailable:

```json
{ "memories": [], "error": "memory_backend_unavailable", "params_used": {...} }
```

### `memory_write`

Persist a durable fact or decision. Falls back to creating an implicit session
when none is active (for example when the agent writes memory outside of a
chat turn).

**Input**

| Field | Type | Required | Default |
|---|---|---|---|
| `content` | string | yes | — |
| `type` | `"decision" \| "preference" \| "fact" \| "observation"` | no | `"observation"` |
| `project` | string | no | `"openclaw"` |

**Output**

```json
{ "ok": true, "observation_id": "obs_abc123" }
```

On failure the `ok` field is `false` and `error` contains the exception
message.

### `memory_compress`

Salience-aware compression of working memory into an episodic summary. Scores
each message, keeps those above `salience_cutoff`, merges the rest into a
single summary observation.

**Input**

| Field | Type | Required | Default |
|---|---|---|---|
| `messages` | `list[{role, content}]` | yes | — |
| `project` | string | no | `"openclaw"` |

**Output**

```json
{
  "kept": 6,
  "compressed": 14,
  "scores": [0.91, 0.22, 0.18, ...],
  "observation_id": "obs_summary_xyz",
  "policy_params": { ... }
}
```

---

## 2. Dashboard REST API

Base URL: `http://localhost:8000` (configurable via `CLAWMEM_DASHBOARD_PORT`).
All responses are JSON unless stated otherwise.

### `GET /api/health`

Dashboard health check — never fails if the process is up.

```json
{ "status": "ok", "service": "clawmemoryX-dashboard", "project": "openclaw" }
```

### `GET /api/about`

Metadata used by the About page; useful for verifying the deployed source URL
matches the hosted code.

```json
{
  "name": "ClawMemory-X",
  "license": "AGPL-3.0",
  "source_url": "https://github.com/SJTU/clawmemoryX",
  "built_on": "claude-mem",
  "claude_mem_url": "https://github.com/thedotmack/claude-mem"
}
```

### Memories

#### `GET /api/memories/list`

Query parameters:

| Name | Type | Default |
|---|---|---|
| `project` | string | `"openclaw"` |
| `limit` | integer | `50` |

```json
{ "memories": [ MemoryIndex, ... ], "backend": "claude-mem" | "unavailable" }
```

#### `GET /api/memories/search`

Query parameters:

| Name | Type | Default |
|---|---|---|
| `q` | string | required |
| `project` | string | `"openclaw"` |
| `limit` | integer | `20` |

Same response shape as `list`.

#### `GET /api/memories/{observation_id}`

Returns the full observation object, or 404 if not found.

### Evolution

#### `GET /api/evolution/history`

```json
{ "trials": [ Trial, ... ] }
```

Each trial:

```json
{
  "run_id": "evolve-20260423T181204Z",
  "trial_number": 17,
  "params": { "vector_weight": 0.58, "top_k": 12, ... },
  "value": 0.74,
  "metrics": { "recall_at_k": 0.9, "task_success_rate": 0.95, ... },
  "state": "COMPLETE",
  "datetime": "2026-04-23T18:14:47+00:00"
}
```

#### `GET /api/evolution/current`

```json
{ "params": { "vector_weight": 0.58, "top_k": 12, ... } }
```

#### `POST /api/evolution/trigger`

Query parameters:

| Name | Type | Default | Meaning |
|---|---|---|---|
| `n_trials` | integer | `10` | Number of TPE trials |
| `apply_best` | boolean | `true` | Write best θ to `current.json` |
| `mode` | `"auto" \| "live" \| "offline" \| null` | `null` | Forwarded to benchmark runner |
| `background` | boolean | `true` | Return immediately and run evolution in the background |

Background response:

```json
{ "status": "scheduled", "n_trials": 10, "mode": "auto" }
```

Foreground response:

```json
{
  "best_params": { ... },
  "best_value": 0.74,
  "n_trials": 30,
  "run_id": "evolve-...",
  "history_path": "policy/data/history.jsonl",
  "optimizer": "optuna-tpe" | "random-fallback"
}
```

### Benchmark

#### `GET /api/benchmark/run`

Query parameters:

| Name | Type | Default |
|---|---|---|
| `mode` | `"auto" \| "live" \| "offline" \| null` | `null` (uses env default) |

```json
{
  "params": { ... },
  "metrics": {
    "recall_at_k": 0.87,
    "task_success_rate": 0.80,
    "token_cost": 4348,
    "max_token_cost": 750000,
    "n_cases": 15,
    "mode": "offline",
    "case_results": [ { "id": "research_001", "recall": 1.0, ... } ]
  }
}
```

---

## 3. CLI entry points

Installed as `pip install -e .` console scripts:

| Command | Equivalent |
|---|---|
| `clawmem-benchmark --mode auto` | `python -m scripts.run_benchmark` |
| `clawmem-evolve --trials 30` | `python -m scripts.trigger_evolution` |
| `clawmem-seed-demo-data` | `python -m scripts.seed_demo_data` |

Arguments match their `argparse` definitions; pass `--help` for details.

---

## 4. Environment variables

See `.env.example` for the full list. Most-used in day-to-day operation:

| Variable | Default | Purpose |
|---|---|---|
| `CLAWMEM_CLAUDE_MEM_URL` | `http://localhost:37777` | Worker URL |
| `CLAWMEM_PROJECT` | `openclaw` | Project scope for writes |
| `CLAWMEM_BENCHMARK_MODE` | `auto` | Default benchmark mode |
| `CLAWMEM_OPTUNA_SEED` | `42` | Reproducible evolution runs |
| `CLAWMEM_POLICY_PATH` | `policy/data/current.json` | Override current θ location |
| `CLAWMEM_HISTORY_PATH` | `policy/data/history.jsonl` | Override history location |
| `DEEPSEEK_API_KEY` | _(unset)_ | Enable LLM-based salience |
| `VITE_API_URL` | _(unset, uses Vite proxy)_ | Frontend API base URL override |
| `VITE_CLAWMEM_SOURCE_URL` | `https://github.com/SJTU/clawmemoryX` | Shown on About page |
