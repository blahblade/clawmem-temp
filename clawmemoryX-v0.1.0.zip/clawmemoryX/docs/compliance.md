# AGPL-3.0 Compliance

ClawMemory-X is distributed under the **GNU Affero General Public License v3.0**
(AGPL-3.0). This document explains what that means in practice, how we satisfy
the requirements, and how to verify compliance before a release.

## 1. Why AGPL-3.0

We build on `claude-mem`, which is itself AGPL-3.0. Derivative works must
inherit the same license, and AGPL's §13 network-use clause matches the
realities of an AI gateway plugin — if you expose our dashboard to users over
the network you must offer them the source code.

If AGPL does not fit your use case, you have two options:

1. Use our HTTP API from a separately-licensed application. HTTP calls do not
   create a derivative work, so your own service can use any license.
2. Ask the copyright holder (the ClawMemory-X team) for a commercial license
   covering your deployment.

## 2. Required files

All of the following must exist at the repository root or in the documented
location. The `scripts/check_compliance.sh` script verifies most of them
automatically.

| Artifact | Location | Status |
|---|---|---|
| Full AGPL-3.0 text | `LICENSE` | shipped |
| Third-party attribution | `NOTICE` | shipped |
| "Built on claude-mem" declaration | `README.md` | shipped |
| Source Code link on dashboard | `dashboard/frontend/src/pages/About.tsx` | shipped |
| AGPL header on every source file | `*.py`, `*.ts`, `*.tsx` | verified by script |
| No modification of claude-mem | — | verified by dependency graph |

## 3. How we satisfy §13 (network use)

Section 13 says: if you modify the software and make it available "by means of
a computer network", users must be able to obtain the source.

Our dashboard covers this in three ways:

1. **Footer link.** Every page has a "Source" link pointing to the repository
   (see `dashboard/frontend/src/components/Layout.tsx`).
2. **Dedicated About page.** `About.tsx` repeats the link, shows the license,
   and credits claude-mem. This is the canonical place users are directed to.
3. **Machine-readable `/api/about`.** Programmatic consumers can hit
   `GET /api/about` to get the repository URL, license identifier, and the
   claude-mem upstream link in JSON form. Useful for audit tools.

The repository URL is configurable via the `CLAWMEM_SOURCE_URL` environment
variable so forks can point to their own repo.

## 4. Header requirement

Every new source file we ship carries this header. `check_compliance.sh` fails
the build if any file is missing it.

**Python:**

```python
# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.
```

**TypeScript/TSX:**

```typescript
// ClawMemory-X — Self-Evolving Memory for OpenClaw
// Copyright (C) 2026 SJTU ClawMemory-X Team
// Licensed under AGPL-3.0. See LICENSE in the project root.
```

## 5. Third-party dependencies

The `NOTICE` file at the repo root attributes:

- **claude-mem** (AGPL-3.0) — the memory storage, compression, and search
  backend. We call it only over HTTP; we do not import, modify, or
  redistribute its source.
- **Optuna** (MIT) — used as the Bayesian optimizer.
- **DeepSeek API** — optional runtime dependency for salience scoring.
- **FastAPI, React, Plotly, Tailwind, etc.** — MIT/BSD/Apache licensed
  libraries used at build/runtime.

For a full runtime license inventory, run:

```bash
pip install pip-licenses
pip-licenses --format=markdown --output-file docs/python_licenses.md

cd dashboard/frontend
npx license-checker --summary
npx license-checker --json > ../../docs/javascript_licenses.json
```

## 6. Release checklist

Before tagging a release, verify:

- [ ] `bash scripts/check_compliance.sh` passes
- [ ] `pytest -q` passes
- [ ] `ruff check .` is clean
- [ ] `npm run build` in `dashboard/frontend` succeeds
- [ ] `README.md` references the correct repo URL
- [ ] `CHANGELOG.md` entry is added
- [ ] `NOTICE` mentions any new third-party dependency
- [ ] License headers exist on any new source file
- [ ] Deployment docs explicitly say AGPL §13 applies if hosted
- [ ] Re-run the license inventory commands above and commit the updated
      `docs/python_licenses.md` / `docs/javascript_licenses.json`

## 7. Fork / modification etiquette

If you fork ClawMemory-X for your own deployment:

1. Keep the `NOTICE` file; add your own attribution lines, do not remove ours.
2. Update `CLAWMEM_SOURCE_URL` and `VITE_CLAWMEM_SOURCE_URL` so your About
   page points to your fork.
3. Keep the AGPL headers on modified files; add a `Modified by <you>` line if
   you want credit.
4. Publish your source if you deploy the dashboard for remote users.

These steps keep you compliant and keep the upstream ecosystem healthy.
