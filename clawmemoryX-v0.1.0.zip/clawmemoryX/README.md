# ClawMemory-X

> Self-evolving long-term memory and context-compression engine for OpenClaw agents.

ClawMemory-X is an OpenClaw Skill/plugin layer that sits on top of `claude-mem` and adds a self-evolving memory policy, salience-aware compression, benchmark evaluation, and a dashboard for observing policy evolution.

## Built On claude-mem

ClawMemory-X is built on top of [claude-mem](https://github.com/thedotmack/claude-mem), an AGPL-3.0 licensed persistent memory system for AI coding agents. claude-mem provides the underlying SQLite + Chroma storage, AI-powered compression, progressive disclosure search, real-time worker UI, and OpenClaw integration hooks. ClawMemory-X adds:

- A self-evolving memory policy layer using Bayesian optimization via Optuna
- Enhanced salience scoring with DeepSeek or deterministic heuristic fallback
- An OpenClaw-native skill package with `memory_read`, `memory_write`, and `memory_compress`
- A dedicated dashboard with memory browsing, benchmark results, and evolution visualization

## Repository layout

```text
clawmemoryX/
├── skill/                  # OpenClaw skill manifest, tools, lifecycle hooks
├── integration/            # HTTP client + SSE subscriber for claude-mem
├── salience/               # Salience scorer and prompts
├── policy/                 # Self-evolving policy engine
├── benchmark/              # 15-case benchmark + offline simulator fallback
├── dashboard/              # FastAPI backend + React/Vite frontend
├── tests/                  # Unit and integration tests
├── scripts/                # CLI helpers and smoke test
└── docs/                   # Architecture, API reference, demo script
```

## Quick start

```bash
git clone https://github.com/SJTU/clawmemoryX.git
cd clawmemoryX
cp .env.example .env
export DEEPSEEK_API_KEY="sk-..."  # optional; heuristic salience works without it
./install.sh
```

Start services from the repository root:

```bash
# terminal 1: claude-mem worker, normally installed by install.sh
curl -fsSL http://localhost:37777/health

# terminal 2: dashboard API
source .venv/bin/activate
uvicorn dashboard.backend.main:app --reload --port 8000

# terminal 3: dashboard frontend
cd dashboard/frontend
npm run dev
```

Open:

- Dashboard API: <http://localhost:8000/api/health>
- Dashboard UI: <http://localhost:5173>
- claude-mem worker/viewer: <http://localhost:37777>

## Demo mode without claude-mem

The benchmark and evolution engine can run in an offline deterministic simulator when `claude-mem` is not reachable. This is intentional so CI, route demos, and early development do not depend on a local worker.

**One-shot demo (recommended).** This seeds evolution history, runs a live benchmark, starts the backend on port 8000 and the Vite dev server on port 5173:

```bash
make demo
# or: bash scripts/demo.sh
```

**Manual offline workflow.** For more control:

```bash
source .venv/bin/activate
python -m scripts.seed_demo_data
python -m scripts.run_benchmark --mode offline
python -m scripts.trigger_evolution --trials 10 --mode offline
uvicorn dashboard.backend.main:app --reload --port 8000
```

## Docker (live demo fallback)

For presentations where the host environment cannot be trusted, a containerized build is available:

```bash
make docker-build       # multi-stage build: Node 20 for frontend + Python 3.11 for runtime
make docker-up          # starts clawmemoryx-dashboard on :8000
open http://localhost:8000    # the backend also serves the built dashboard

make docker-down        # stop the container
```

The container is self-sufficient (demo data is pre-seeded during the build). If a `claude-mem` worker is running on the host, the container reaches it through `host.docker.internal:37777` automatically on macOS/Windows, and via the `extra_hosts` entry in `docker-compose.yml` on Linux.

## OpenClaw Skill installation

`install.sh` copies `skill/` into `~/.openclaw/skills/clawmemoryX`. The repository includes both:

- `skill/skill.json` for the delivery framework manifest
- `skill/SKILL.md` for AgentSkills-style skill discovery

Restart the OpenClaw Gateway after installing.

## Main APIs

Dashboard REST endpoints:

| Method | Path | Description |
|---|---|---|
| GET | `/api/health` | Dashboard health check |
| GET | `/api/memories/list?project=openclaw&limit=50` | List memory index entries |
| GET | `/api/memories/search?q=FastAPI&limit=20` | Search memory |
| GET | `/api/evolution/current` | Current policy parameters |
| GET | `/api/evolution/history` | Evolution trial history |
| POST | `/api/evolution/trigger?n_trials=10` | Trigger policy evolution |
| GET | `/api/benchmark/run?mode=offline` | Run benchmark |

## Tests

```bash
source .venv/bin/activate
pytest -q
ruff check .
mypy integration salience policy benchmark dashboard skill scripts
```

Frontend build:

```bash
cd dashboard/frontend
npm install
npm run build
```

## License

This project is licensed under AGPL-3.0. See [LICENSE](LICENSE) for full text.

## Source Code

Full source code is available at: <https://github.com/SJTU/clawmemoryX>

Per AGPL-3.0 §13, if you deploy ClawMemory-X as a network service, you must provide users with access to the corresponding source code.

## Compliance status

- Full AGPL-3.0 license text: `LICENSE`
- Third-party attribution: `NOTICE`
- Dashboard Source/About page: `dashboard/frontend/src/pages/About.tsx`
- Source headers on Python and TypeScript/TSX files
- No modifications to claude-mem source code
