# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Salience scorer with DeepSeek API support and deterministic fallback."""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
from typing import Any

import httpx

from salience.prompts import SALIENCE_SCORING_PROMPT

logger = logging.getLogger(__name__)

DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1")
DEEPSEEK_MODEL = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")

HIGH_VALUE_PATTERNS = re.compile(
    r"\b(decision|decided|prefer|preference|must|requirement|deadline|api|sdk|"
    r"fastapi|react|python|typescript|sqlite|chroma|optuna|openclaw|claude-mem|"
    r"客户|偏好|必须|决定|要求|截止|接口|项目|框架)\b",
    re.IGNORECASE,
)
LOW_VALUE_PATTERNS = re.compile(r"^(ok|okay|thanks|thank you|hi|hello|收到|好的|谢谢|嗯)[.!。！\s]*$", re.IGNORECASE)


class SalienceCache:
    """Content-hash to score cache."""

    def __init__(self) -> None:
        self._cache: dict[str, float] = {}

    @staticmethod
    def key(content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]

    def get(self, content: str) -> float | None:
        return self._cache.get(self.key(content))

    def set(self, content: str, score: float) -> None:
        self._cache[self.key(content)] = score


_cache = SalienceCache()


async def score_messages(messages: list[dict[str, Any]]) -> list[float]:
    """Score messages in the same order as input.

    If `DEEPSEEK_API_KEY` is absent or the API call fails, a deterministic
    heuristic is used so compression and tests remain usable.
    """

    if not messages:
        return []

    scores: list[float | None] = [None] * len(messages)
    uncached_indices: list[int] = []
    uncached_messages: list[dict[str, Any]] = []

    for i, message in enumerate(messages):
        content = str(message.get("content", ""))
        cached = _cache.get(content)
        if cached is None:
            uncached_indices.append(i)
            uncached_messages.append(message)
        else:
            scores[i] = cached

    if uncached_messages:
        new_scores = await _score_uncached(uncached_messages)
        for idx, score in zip(uncached_indices, new_scores, strict=False):
            clamped = _clamp(score)
            scores[idx] = clamped
            _cache.set(str(messages[idx].get("content", "")), clamped)

    return [float(score if score is not None else 0.5) for score in scores]


async def _score_uncached(messages: list[dict[str, Any]]) -> list[float]:
    if not DEEPSEEK_API_KEY:
        return [_heuristic_score(message) for message in messages]

    formatted = "\n".join(
        f"{i}. [{message.get('role', 'user')}] {str(message.get('content', ''))[:600]}"
        for i, message in enumerate(messages, start=1)
    )
    prompt = SALIENCE_SCORING_PROMPT.format(messages=formatted)

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{DEEPSEEK_BASE_URL}/chat/completions",
                headers={"Authorization": f"Bearer {DEEPSEEK_API_KEY}"},
                json={
                    "model": DEEPSEEK_MODEL,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.0,
                    "response_format": {"type": "json_object"},
                },
            )
            response.raise_for_status()
            payload = response.json()
            content = payload["choices"][0]["message"]["content"]
            parsed = json.loads(content)
            raw_scores = parsed if isinstance(parsed, list) else parsed.get("scores", [])
            if len(raw_scores) != len(messages):
                raise ValueError("score count mismatch")
            return [float(score) for score in raw_scores]
    except Exception as exc:
        logger.warning("DeepSeek salience scoring failed; using heuristic fallback: %s", exc)
        return [_heuristic_score(message) for message in messages]


def _heuristic_score(message: dict[str, Any]) -> float:
    content = str(message.get("content", "")).strip()
    role = str(message.get("role", "user"))
    if not content:
        return 0.0
    if LOW_VALUE_PATTERNS.match(content):
        return 0.1

    score = 0.25
    if role == "user":
        score += 0.1
    if HIGH_VALUE_PATTERNS.search(content):
        score += 0.35
    if re.search(r"[A-Z][A-Za-z0-9_-]{2,}|\d{4}-\d{2}-\d{2}|https?://|\b[A-Z]{2,}\b", content):
        score += 0.15
    if len(content) > 180:
        score += 0.1
    if "error" in content.lower() or "traceback" in content.lower() or "报错" in content:
        score += 0.15
    return _clamp(score)


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, float(value)))
