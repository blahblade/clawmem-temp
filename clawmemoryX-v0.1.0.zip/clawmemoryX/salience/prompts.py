# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Prompt templates for salience scoring."""

SALIENCE_SCORING_PROMPT = """You are a memory salience evaluator. Given messages from a conversation,
rate each message's importance on a scale of 0.0 to 1.0 for long-term retention.

High salience (0.7-1.0):
- Explicit decisions or commitments
- User preferences or constraints
- Technical requirements or specs
- Named entities such as people, projects, tools, APIs, packages, and deadlines
- Instructions that modify agent behavior

Medium salience (0.3-0.7):
- Concrete facts that may be referenced later
- Error messages or debugging information
- Partial context needed for follow-ups

Low salience (0.0-0.3):
- Greetings, acknowledgments
- Repetitions of known information
- Filler content

Respond with ONLY JSON using this schema: {"scores": [0.85, 0.15, 0.62]}.
The number of scores must match the number of input messages.

Messages:
{messages}
"""
