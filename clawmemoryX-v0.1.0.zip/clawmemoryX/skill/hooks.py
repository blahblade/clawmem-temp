# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""OpenClaw lifecycle hooks.

The exact hook names may differ across OpenClaw versions, so this module exposes
both the delivery-framework names and a `before_prompt_build` alias.
"""

from __future__ import annotations

import logging
from contextvars import ContextVar
from typing import Any

from integration.claude_mem_client import ClaudeMemClient
from policy.current import get_current_params

logger = logging.getLogger(__name__)

_current_session_id: ContextVar[str | None] = ContextVar("current_session_id", default=None)


def set_current_session_id(session_id: str | None) -> None:
    _current_session_id.set(session_id)


def get_current_session_id(required: bool = True) -> str | None:
    session_id = _current_session_id.get()
    if required and not session_id:
        raise RuntimeError("No active memory session. Did on_session_start fire?")
    return session_id


async def on_session_start(context: dict[str, Any]) -> dict[str, Any]:
    project = str(context.get("project") or context.get("config", {}).get("project") or "openclaw")
    user_prompt = str(context.get("user_prompt") or context.get("prompt") or "")

    async with ClaudeMemClient() as client:
        if not await client.health():
            logger.warning("claude-mem worker unavailable during session start")
            return {"appendSystemContext": ""}
        session = await client.init_session(project=project, user_prompt=user_prompt)
        set_current_session_id(str(session["session_id"]))
        markdown_context = await client.inject_context(project=project)
        return {"appendSystemContext": markdown_context}


async def before_prompt_build(context: dict[str, Any]) -> dict[str, Any]:
    """OpenClaw before_prompt_build hook alias for context injection."""

    return await on_session_start(context)


async def on_turn_end(context: dict[str, Any]) -> dict[str, Any]:
    params = get_current_params()
    current_tokens = int(context.get("estimated_tokens") or context.get("tokens") or 0)
    auto_compress = bool(context.get("auto_compress", True))

    if auto_compress and current_tokens >= int(params["compression_threshold"]):
        from skill.memory_compress import memory_compress

        await memory_compress(messages=list(context.get("messages", [])), project=str(context.get("project", "openclaw")))
    return {}


async def on_session_end(context: dict[str, Any]) -> dict[str, Any]:
    session_id = get_current_session_id(required=False)
    if session_id:
        async with ClaudeMemClient() as client:
            await client.complete_session(session_id)
        set_current_session_id(None)
    return {}


async def tool_result_persist(context: dict[str, Any]) -> dict[str, Any]:
    """Optional hook to persist tool results as observations."""

    session_id = get_current_session_id(required=False)
    if not session_id:
        return {}
    content = str(context.get("content") or context.get("result") or "")
    if not content or "<private>" in content:
        return {}
    project = str(context.get("project", "openclaw"))
    async with ClaudeMemClient() as client:
        if await client.health():
            await client.record_observation(
                session_id=session_id,
                content=content[:4000],
                obs_type="tool_result",
                project=project,
                metadata={"tool": context.get("tool")},
            )
    return {}
