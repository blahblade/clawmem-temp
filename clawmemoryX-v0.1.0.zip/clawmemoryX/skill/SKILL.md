---
name: clawmemoryX
description: Self-evolving long-term memory and context compression for OpenClaw agents.
license: AGPL-3.0
---

# ClawMemory-X Skill

Use this skill when the agent needs to persist, recall, or compress long-term project memory.

## Tools

- `memory_read(query, top_k?, project?)`: retrieve relevant long-term memories.
- `memory_write(content, type?, project?)`: persist a decision, preference, fact, or observation.
- `memory_compress(messages, project?)`: salience-aware compression of working memory into episodic summaries.

## Operating rules

1. Prefer `memory_write` for durable user preferences, project decisions, deadlines, API choices, and technical constraints.
2. Use `memory_read` when the user asks to continue prior work, references "昨天/上次/之前", or asks about a known project.
3. Never store secrets, credentials, private keys, or content explicitly wrapped in `<private>...</private>`.
4. ClawMemory-X calls claude-mem over HTTP and should degrade gracefully when the worker is unavailable.

Source code: https://github.com/SJTU/clawmemoryX
