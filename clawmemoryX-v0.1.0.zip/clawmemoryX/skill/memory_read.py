# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""memory_read tool: retrieve relevant memories for an agent query."""

from __future__ import annotations

from typing import Any

from integration.claude_mem_client import ClaudeMemClient
from policy.current import get_current_params


async def memory_read(query: str, top_k: int | None = None, project: str = "openclaw") -> dict[str, Any]:
    params = get_current_params()
    effective_top_k = int(top_k or params["top_k"])

    async with ClaudeMemClient() as client:
        if not await client.health():
            return {"memories": [], "error": "memory_backend_unavailable", "params_used": params}

        index = await client.search(query=query, limit=effective_top_k, project=project)
        if not index:
            return {"memories": [], "params_used": params, "retrieved_count": 0}

        observations = await client.get_observations(ids=[item.id for item in index])
        return {
            "memories": observations,
            "index": [item.to_dict() for item in index],
            "params_used": params,
            "retrieved_count": len(observations),
        }
