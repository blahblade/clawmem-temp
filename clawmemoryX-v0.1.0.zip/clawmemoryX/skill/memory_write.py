# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""memory_write tool: explicitly persist a durable memory."""

from __future__ import annotations

from typing import Any, Literal

from integration.claude_mem_client import ClaudeMemClient
from skill.hooks import get_current_session_id, set_current_session_id

MemoryType = Literal["decision", "preference", "fact", "observation"]


async def memory_write(
    content: str,
    type: MemoryType = "observation",
    project: str = "openclaw",
) -> dict[str, Any]:
    async with ClaudeMemClient() as client:
        try:
            session_id = get_current_session_id(required=False)
            if not session_id:
                session = await client.init_session(project=project, user_prompt="manual_memory_write")
                session_id = str(session["session_id"])
                set_current_session_id(session_id)

            result = await client.record_observation(
                session_id=session_id,
                content=content,
                obs_type=type,
                project=project,
            )
            return {"ok": True, "observation_id": result.get("id") or result.get("observation_id")}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}
