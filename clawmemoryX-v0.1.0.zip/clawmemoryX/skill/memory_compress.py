# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""memory_compress tool: salience-aware compression into episodic memory."""

from __future__ import annotations

from typing import Any

from integration.claude_mem_client import ClaudeMemClient
from policy.current import get_current_params
from salience.scorer import score_messages
from skill.hooks import get_current_session_id, set_current_session_id


async def memory_compress(messages: list[dict[str, Any]], project: str = "openclaw") -> dict[str, Any]:
    params = get_current_params()
    cutoff = float(params["salience_cutoff"])
    scores = await score_messages(messages)

    kept = [message for message, score in zip(messages, scores, strict=False) if score >= cutoff]
    to_compress = [message for message, score in zip(messages, scores, strict=False) if score < cutoff]

    if not to_compress:
        return {"kept": len(kept), "compressed": 0, "scores": scores, "policy_params": params}

    async with ClaudeMemClient() as client:
        try:
            session_id = get_current_session_id(required=False)
            if not session_id:
                session = await client.init_session(project=project, user_prompt="auto_compress")
                session_id = str(session["session_id"])
                set_current_session_id(session_id)

            summary_text = "\n".join(
                f"[{message.get('role', 'unknown')}] {str(message.get('content', ''))[:240]}"
                for message in to_compress
            )
            compressed_summary = (
                f"Episodic summary of {len(to_compress)} low-salience messages:\n"
                f"{summary_text[:2400]}"
            )
            result = await client.record_observation(
                session_id=session_id,
                content=compressed_summary,
                obs_type="episodic_summary",
                project=project,
                metadata={"scores": scores, "policy_params": params},
            )
            return {
                "kept": len(kept),
                "compressed": len(to_compress),
                "scores": scores,
                "observation_id": result.get("id") or result.get("observation_id"),
                "policy_params": params,
            }
        except Exception as exc:
            return {"kept": len(kept), "compressed": len(to_compress), "error": str(exc), "scores": scores}
