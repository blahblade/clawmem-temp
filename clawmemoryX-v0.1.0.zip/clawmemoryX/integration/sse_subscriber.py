# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""SSE subscriber for claude-mem real-time observation stream."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import Any

from integration.claude_mem_client import ClaudeMemClient

logger = logging.getLogger(__name__)

ObservationHandler = Callable[[dict[str, Any]], Awaitable[None]]


async def subscribe_observations(
    handler: ObservationHandler,
    base_url: str | None = None,
    reconnect_delay: float = 5.0,
    stop_after_errors: int | None = None,
) -> None:
    """Subscribe forever to `/stream` and call `handler` for each event."""

    errors = 0
    while True:
        async with ClaudeMemClient(base_url=base_url) as client:
            try:
                async for event in client.stream_observations():
                    errors = 0
                    await handler(event)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover - network dependent
                errors += 1
                logger.warning("SSE subscriber disconnected: %s", exc)
                if stop_after_errors is not None and errors >= stop_after_errors:
                    raise
                await asyncio.sleep(reconnect_delay)
