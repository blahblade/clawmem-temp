# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""HTTP client wrapper for claude-mem.

All calls to the memory backend should go through this module. The client is
intentionally defensive: health checks, searches, and observation fetches degrade
to safe empty results instead of crashing OpenClaw when the worker is unavailable.
"""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncIterator
from dataclasses import asdict, dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = os.environ.get("CLAWMEM_CLAUDE_MEM_URL", "http://localhost:37777")
DEFAULT_TIMEOUT = float(os.environ.get("CLAWMEM_CLAUDE_MEM_TIMEOUT", "10"))


@dataclass(slots=True)
class ObservationIndex:
    """Progressive-disclosure index entry returned by claude-mem search."""

    id: str
    title: str = ""
    snippet: str = ""
    score: float = 0.0
    type: str | None = None
    project: str | None = None
    created_at: str | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> ObservationIndex:
        return cls(
            id=str(payload.get("id") or payload.get("observation_id") or ""),
            title=str(payload.get("title") or payload.get("summary") or ""),
            snippet=str(payload.get("snippet") or payload.get("content") or "")[:500],
            score=float(payload.get("score") or payload.get("relevance") or 0.0),
            type=payload.get("type"),
            project=payload.get("project"),
            created_at=payload.get("created_at") or payload.get("timestamp"),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ClaudeMemClient:
    """Async HTTP client for claude-mem worker endpoints."""

    def __init__(
        self,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self._client = httpx.AsyncClient(timeout=timeout, transport=transport)

    async def __aenter__(self) -> ClaudeMemClient:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    async def health(self) -> bool:
        try:
            response = await self._client.get(f"{self.base_url}/health")
            return 200 <= response.status_code < 300
        except Exception as exc:  # pragma: no cover - exact network failures vary
            logger.warning("claude-mem health check failed: %s", exc)
            return False

    async def init_session(self, project: str, user_prompt: str) -> dict[str, Any]:
        response = await self._client.post(
            f"{self.base_url}/api/sessions/init",
            json={"project": project, "user_prompt": user_prompt},
        )
        response.raise_for_status()
        data = _response_json(response)
        if isinstance(data, list):
            data = {"items": data}
        if "session_id" not in data:
            data["session_id"] = data.get("id", "unknown-session")
        return data

    async def record_observation(
        self,
        session_id: str,
        content: str,
        obs_type: str = "observation",
        project: str = "openclaw",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response = await self._client.post(
            f"{self.base_url}/api/sessions/observations",
            json={
                "session_id": session_id,
                "content": content,
                "type": obs_type,
                "project": project,
                "metadata": metadata or {},
            },
        )
        response.raise_for_status()
        data = _response_json(response)
        return data if isinstance(data, dict) else {"items": data}

    async def summarize_session(self, session_id: str) -> dict[str, Any]:
        response = await self._client.post(
            f"{self.base_url}/api/sessions/summarize",
            json={"session_id": session_id},
        )
        response.raise_for_status()
        data = _response_json(response)
        return data if isinstance(data, dict) else {"items": data}

    async def complete_session(self, session_id: str) -> None:
        try:
            response = await self._client.post(
                f"{self.base_url}/api/sessions/complete",
                json={"session_id": session_id},
            )
            if response.status_code not in {200, 201, 202, 204, 404}:
                response.raise_for_status()
        except Exception as exc:
            logger.warning("failed to complete claude-mem session %s: %s", session_id, exc)

    async def inject_context(self, project: str) -> str:
        try:
            response = await self._client.get(
                f"{self.base_url}/api/context/inject",
                params={"projects": project},
            )
            if response.status_code == 404:
                return ""
            response.raise_for_status()
            return response.text
        except Exception as exc:
            logger.warning("context injection failed for project=%s: %s", project, exc)
            return ""

    async def search(
        self,
        query: str,
        limit: int = 10,
        type_filter: str | None = None,
        project: str | None = None,
    ) -> list[ObservationIndex]:
        """Progressive Disclosure layer 1: fetch lightweight index entries."""

        payload: dict[str, Any] = {"query": query, "limit": int(limit)}
        if type_filter:
            payload["type"] = type_filter
        if project:
            payload["project"] = project
            payload["projects"] = project

        try:
            response = await self._client.post(f"{self.base_url}/api/search", json=payload)
            if response.status_code == 404:
                response = await self._client.get(f"{self.base_url}/api/search", params=payload)
            if response.status_code == 404:
                logger.warning("claude-mem search endpoint unavailable")
                return []
            response.raise_for_status()
            data = _response_json(response)
            raw_results = data if isinstance(data, list) else data.get("results") or data.get("memories") or []
            return [ObservationIndex.from_payload(item) for item in raw_results if isinstance(item, dict)]
        except Exception as exc:
            logger.warning("claude-mem search failed query=%r: %s", query, exc)
            return []

    async def get_observation(self, observation_id: str | int) -> dict[str, Any] | None:
        try:
            response = await self._client.get(f"{self.base_url}/api/observation/{observation_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            data = _response_json(response)
            return data if isinstance(data, dict) else {"items": data}
        except Exception as exc:
            logger.warning("failed to fetch observation %s: %s", observation_id, exc)
            return None

    async def get_observations(self, ids: list[str | int]) -> list[dict[str, Any]]:
        """Progressive Disclosure layer 2: fetch full observation details."""

        if not ids:
            return []
        try:
            response = await self._client.post(
                f"{self.base_url}/api/observations/batch",
                json={"ids": [str(i) for i in ids]},
            )
            if response.status_code != 404:
                response.raise_for_status()
                data = _response_json(response)
                observations = data if isinstance(data, list) else data.get("observations") or data.get("results") or []
                return [item for item in observations if isinstance(item, dict)]
        except Exception as exc:
            logger.warning("batch observation fetch failed; falling back to individual fetch: %s", exc)

        observations: list[dict[str, Any]] = []
        for observation_id in ids:
            item = await self.get_observation(observation_id)
            if item:
                observations.append(item)
        return observations

    async def stream_observations(self) -> AsyncIterator[dict[str, Any]]:
        """Yield parsed SSE events from `/stream`."""

        async with self._client.stream("GET", f"{self.base_url}/stream") as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data:"):
                    continue
                raw = line.split("data:", 1)[1].strip()
                if not raw:
                    continue
                try:
                    yield json.loads(raw)
                except json.JSONDecodeError:
                    yield {"event": "raw", "data": raw}


def _response_json(response: httpx.Response) -> dict[str, Any] | list[Any]:
    if not response.content:
        return {}
    try:
        return response.json()
    except json.JSONDecodeError:
        return {"text": response.text}
