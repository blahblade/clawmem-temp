#!/usr/bin/env bash
set -euo pipefail

echo "========================================="
echo "ClawMemory-X Installer"
echo "========================================="

PYTHON_BIN="${PYTHON_BIN:-python3}"
$PYTHON_BIN - <<'PY'
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Need Python 3.11+")
print(f"[1/7] Python {sys.version_info.major}.{sys.version_info.minor} OK")
PY

if command -v openclaw >/dev/null 2>&1; then
  echo "[2/7] OpenClaw CLI found"
else
  echo "[2/7] OpenClaw CLI not found; continuing because dashboard/demo mode can still run"
fi

if curl -fsSL http://localhost:37777/health >/dev/null 2>&1; then
  echo "[3/7] claude-mem worker already running"
else
  if [[ "${CLAWMEM_SKIP_CLAUDE_MEM_INSTALL:-0}" == "1" ]]; then
    echo "[3/7] claude-mem worker unavailable; skipped installer by CLAWMEM_SKIP_CLAUDE_MEM_INSTALL=1"
  else
    echo "[3/7] Installing claude-mem via official installer..."
    curl -fsSL https://install.cmem.ai/openclaw.sh | bash || {
      echo "claude-mem install did not complete. You can still use offline benchmark/demo mode."
    }
  fi
fi

echo "[4/7] Installing Python dependencies..."
$PYTHON_BIN -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e ".[dashboard,test]"

echo "[5/7] Initializing policy data..."
python - <<'PY'
from policy.current import ensure_current_params
ensure_current_params()
print("policy/data/current.json ready")
PY

echo "[6/7] Installing/building dashboard frontend..."
if command -v npm >/dev/null 2>&1; then
  pushd dashboard/frontend >/dev/null
  npm install
  npm run build
  popd >/dev/null
else
  echo "npm not found; skipped frontend build"
fi

echo "[7/7] Registering OpenClaw skill folder..."
SKILL_DIR="${OPENCLAW_SKILL_DIR:-$HOME/.openclaw/skills/clawmemoryX}"
mkdir -p "$SKILL_DIR"
cp -R skill/. "$SKILL_DIR/"

echo ""
echo "✅ Installation complete"
echo ""
echo "Next steps:"
echo "  1. export DEEPSEEK_API_KEY='your_key'  # optional"
echo "  2. source .venv/bin/activate"
echo "  3. uvicorn dashboard.backend.main:app --reload --port 8000"
echo "  4. cd dashboard/frontend && npm run dev"
echo "  5. Restart OpenClaw Gateway to load the skill"
