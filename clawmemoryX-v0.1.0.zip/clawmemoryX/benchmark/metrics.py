# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Benchmark metrics."""

from __future__ import annotations

from typing import Any

try:  # pragma: no cover - depends on optional wheel availability
    import tiktoken

    _ENC = tiktoken.get_encoding("cl100k_base")
except Exception:  # pragma: no cover
    _ENC = None


def compute_recall(retrieved: list[dict[str, Any]], expected: list[str]) -> float:
    if not expected:
        return 1.0
    retrieved_text = " ".join(
        str(obs.get("content", "")) + " " + str(obs.get("title", "")) + " " + str(obs.get("snippet", ""))
        for obs in retrieved
    ).lower()
    hits = sum(1 for keyword in expected if keyword.lower() in retrieved_text)
    return hits / len(expected)


def compute_success(retrieved: list[dict[str, Any]], expected: list[str]) -> float:
    return 1.0 if compute_recall(retrieved, expected) >= 0.8 else 0.0


def count_tokens(items: Any) -> int:
    if isinstance(items, list):
        text = " ".join(
            str(item.get("content", "")) if isinstance(item, dict) else str(item) for item in items
        )
    else:
        text = str(items)
    if _ENC is None:
        return max(1, len(text.split()))
    return len(_ENC.encode(text))
