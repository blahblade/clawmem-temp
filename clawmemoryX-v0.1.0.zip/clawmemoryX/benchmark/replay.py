# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Replay benchmark cases into a live claude-mem worker."""

from __future__ import annotations

from typing import Any

from integration.claude_mem_client import ClaudeMemClient


async def replay_turns(client: ClaudeMemClient, turns: list[dict[str, Any]], project: str) -> None:
    session = await client.init_session(project=project, user_prompt="benchmark_replay")
    session_id = str(session["session_id"])
    for turn in turns:
        await client.record_observation(
            session_id=session_id,
            content=f"[{turn.get('role', 'unknown')}] {turn.get('content', '')}",
            obs_type="benchmark_turn",
            project=project,
            metadata={"benchmark": True},
        )
    await client.complete_session(session_id)


async def execute_query(client: ClaudeMemClient, query: str, project: str, top_k: int) -> dict[str, Any]:
    index = await client.search(query=query, limit=top_k, project=project)
    ids = [item.id for item in index]
    if not ids:
        return {"memories": []}
    observations = await client.get_observations(ids=ids)
    return {"memories": observations}
