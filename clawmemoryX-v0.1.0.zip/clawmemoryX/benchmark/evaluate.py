# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Benchmark runner with live claude-mem and offline simulator modes."""

from __future__ import annotations

import json
import math
import os
import re
import uuid
from pathlib import Path
from typing import Any

from benchmark.metrics import compute_recall, compute_success, count_tokens
from benchmark.replay import execute_query, replay_turns
from integration.claude_mem_client import ClaudeMemClient
from policy.params import sanitize_params

DATASET_PATH = Path(__file__).parent / "dataset.jsonl"
TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_+-]*|[\u4e00-\u9fff]+|\d+")


def load_cases(dataset_path: Path = DATASET_PATH) -> list[dict[str, Any]]:
    return [json.loads(line) for line in dataset_path.read_text(encoding="utf-8").splitlines() if line.strip()]


async def run_benchmark(
    params: dict[str, Any],
    dataset_path: Path = DATASET_PATH,
    mode: str | None = None,
) -> dict[str, Any]:
    """Run benchmark and return aggregate metrics.

    mode:
      - live: require claude-mem worker
      - offline: deterministic simulator
      - auto: live if worker is healthy, otherwise offline
    """

    params = sanitize_params(params)
    mode = (mode or os.environ.get("CLAWMEM_BENCHMARK_MODE", "auto")).lower()
    cases = load_cases(dataset_path)
    if mode not in {"auto", "live", "offline"}:
        raise ValueError("mode must be auto, live, or offline")

    if mode in {"auto", "live"}:
        async with ClaudeMemClient() as client:
            healthy = await client.health()
        if healthy:
            return await _run_live(params, cases)
        if mode == "live":
            raise RuntimeError("claude-mem worker is not reachable; use mode=offline or mode=auto")

    return _run_offline(params, cases)


async def _run_live(params: dict[str, Any], cases: list[dict[str, Any]]) -> dict[str, Any]:
    recalls: list[float] = []
    successes: list[float] = []
    token_costs: list[int] = []
    case_results: list[dict[str, Any]] = []

    for case in cases:
        project = f"{os.environ.get('CLAWMEM_BENCH_PREFIX', 'bench_')}{case['id']}_{uuid.uuid4().hex[:8]}"
        async with ClaudeMemClient() as client:
            await replay_turns(client, case["turns"], project=project)
            result = await execute_query(
                client,
                query=case["ground_truth"]["retrieval_query"],
                project=project,
                top_k=int(params["top_k"]),
            )

        recall = compute_recall(result["memories"], case["ground_truth"]["expected_retrieval_includes"])
        success = compute_success(result["memories"], case["ground_truth"]["expected_answer_contains"])
        tokens = count_tokens(result["memories"]) + count_tokens(case["turns"])
        recalls.append(recall)
        successes.append(success)
        token_costs.append(tokens)
        case_results.append({"id": case["id"], "recall": recall, "success": success, "token_cost": tokens})

    return _aggregate(recalls, successes, token_costs, cases, "live", case_results)


def _run_offline(params: dict[str, Any], cases: list[dict[str, Any]]) -> dict[str, Any]:
    recalls: list[float] = []
    successes: list[float] = []
    token_costs: list[int] = []
    case_results: list[dict[str, Any]] = []

    for case in cases:
        retrieved = _offline_retrieve(case, params)
        raw_recall = compute_recall(retrieved, case["ground_truth"]["expected_retrieval_includes"])
        quality = _policy_quality(case, params)
        recall = max(0.0, min(1.0, raw_recall * quality))
        success = 1.0 if recall >= 0.8 else max(0.0, recall - 0.15)
        tokens = _offline_token_cost(case, retrieved, params)
        recalls.append(recall)
        successes.append(success)
        token_costs.append(tokens)
        case_results.append(
            {
                "id": case["id"],
                "category": case["category"],
                "recall": recall,
                "success": success,
                "token_cost": tokens,
            }
        )

    return _aggregate(recalls, successes, token_costs, cases, "offline", case_results)


def _offline_retrieve(case: dict[str, Any], params: dict[str, Any]) -> list[dict[str, Any]]:
    query = case["ground_truth"]["retrieval_query"]
    expected = case["ground_truth"]["expected_retrieval_includes"]
    vector_weight = float(params["vector_weight"])
    top_k = int(params["top_k"])
    retention = int(params["episodic_retention"])
    age_days = int(case.get("age_days", 7))

    records: list[dict[str, Any]] = []
    for index, turn in enumerate(case["turns"]):
        content = f"[{turn.get('role', 'user')}] {turn.get('content', '')}"
        salience = _offline_salience(content, expected)
        if age_days > retention and salience < 0.75:
            continue
        if salience < float(params["salience_cutoff"]):
            content = _compress_text(content, keep_terms=expected)
        records.append(
            {
                "id": f"{case['id']}-{index}",
                "title": f"{case['category']} turn {index + 1}",
                "content": content,
                "score": 0.0,
                "type": "offline_observation",
            }
        )

    total_tokens = count_tokens(case["turns"])
    if total_tokens > int(params["compression_threshold"]):
        keep_count = max(1, min(len(expected), round((1.0 - float(params["salience_cutoff"])) * len(expected))))
        summary_terms = ", ".join(expected[:keep_count])
        records.append(
            {
                "id": f"{case['id']}-summary",
                "title": "episodic summary",
                "content": f"Episodic summary: important facts include {summary_terms}.",
                "score": 0.0,
                "type": "episodic_summary",
            }
        )

    query_tokens = set(_tokens(query))
    expected_tokens = {t.lower() for term in expected for t in _tokens(term)}
    scored: list[dict[str, Any]] = []
    for record in records:
        content_tokens = set(_tokens(record["content"]))
        keyword_score = _jaccard(query_tokens | expected_tokens, content_tokens)
        semantic_score = _semantic_overlap(expected_tokens, content_tokens, case["category"])
        exact_boost = sum(1 for term in expected if term.lower() in record["content"].lower()) / max(1, len(expected))
        score = (1 - vector_weight) * keyword_score + vector_weight * semantic_score + 0.4 * exact_boost
        score -= abs(vector_weight - 0.58) * 0.05
        record = dict(record)
        record["score"] = score
        scored.append(record)

    scored.sort(key=lambda item: item["score"], reverse=True)
    return scored[:top_k]


def _offline_salience(content: str, expected: list[str]) -> float:
    text = content.lower()
    score = 0.25
    if any(term.lower() in text for term in expected):
        score += 0.45
    if any(marker in text for marker in ["决定", "必须", "prefer", "decision", "deadline", "api", "sop", "error", "fastapi"]):
        score += 0.2
    if len(content) > 220:
        score += 0.1
    return min(1.0, score)


def _compress_text(content: str, keep_terms: list[str]) -> str:
    kept = [term for term in keep_terms if term.lower() in content.lower()]
    if kept:
        return "Compressed low-salience context. Retained key terms: " + ", ".join(kept)
    return "Compressed low-salience context."


def _policy_quality(case: dict[str, Any], params: dict[str, Any]) -> float:
    vector_weight = float(params["vector_weight"])
    top_k = int(params["top_k"])
    threshold = int(params["compression_threshold"])
    cutoff = float(params["salience_cutoff"])
    retention = int(params["episodic_retention"])
    age_days = int(case.get("age_days", 7))
    category = str(case.get("category", ""))

    quality = 0.72
    quality += 0.18 * (1 - min(1.0, abs(vector_weight - 0.58) / 0.58))
    quality += 0.14 * (1 - math.exp(-top_k / 8))
    quality += 0.08 * (1 - min(1.0, abs(cutoff - 0.28) / 0.4))
    quality += 0.05 * (1 - min(1.0, abs(threshold - 7000) / 12000))
    if category == "long_span":
        quality += 0.08 if retention >= age_days else -0.2
    return max(0.35, min(1.0, quality))


def _offline_token_cost(case: dict[str, Any], retrieved: list[dict[str, Any]], params: dict[str, Any]) -> int:
    base = count_tokens(retrieved) + min(count_tokens(case["turns"]), int(params["compression_threshold"]))
    top_k_penalty = int(params["top_k"]) * 18
    retention_penalty = int(int(params["episodic_retention"]) * 2)
    return int(base + top_k_penalty + retention_penalty)


def _aggregate(
    recalls: list[float],
    successes: list[float],
    token_costs: list[int],
    cases: list[dict[str, Any]],
    mode: str,
    case_results: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "recall_at_k": sum(recalls) / len(recalls) if recalls else 0.0,
        "task_success_rate": sum(successes) / len(successes) if successes else 0.0,
        "token_cost": sum(token_costs),
        "max_token_cost": max(1, len(cases) * 50000),
        "n_cases": len(cases),
        "mode": mode,
        "case_results": case_results,
    }


def _tokens(text: str) -> list[str]:
    return [token.lower() for token in TOKEN_RE.findall(text)]


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _semantic_overlap(expected: set[str], content: set[str], category: str) -> float:
    if not expected or not content:
        return 0.0
    overlap = len(expected & content) / len(expected)
    category_bonus = 0.05 if any(token in content for token in _tokens(category)) else 0.0
    return min(1.0, overlap + category_bonus)
