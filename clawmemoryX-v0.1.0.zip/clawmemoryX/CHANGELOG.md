# Changelog

All notable changes to ClawMemory-X are documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] — 2026-04-25

First delivery for the SJTU OpenClaw Innovation Contest 2026.

### Added

- **OpenClaw Skill layer** with three tools (`memory_read`, `memory_write`,
  `memory_compress`) and five lifecycle hooks (`before_prompt_build`,
  `on_session_start`, `on_turn_end`, `tool_result_persist`, `on_session_end`).
- **Self-evolving policy engine** using Optuna TPE over a 5-dimensional
  parameter space (`vector_weight`, `top_k`, `compression_threshold`,
  `salience_cutoff`, `episodic_retention`). Includes a deterministic random
  fallback if Optuna is unavailable.
- **Salience scorer** with DeepSeek API support and a heuristic fallback so
  the system is fully functional without any API key.
- **15-case benchmark** spanning research-assistant, business-process, and
  long-span categories, runnable in `live` or `offline` mode. The offline
  simulator is deterministic and designed so `vector_weight ≈ 0.58` is the
  optimum — this is the story the Evolution Chart tells.
- **Dashboard** built with FastAPI + React + Plotly, featuring a Memory
  Browser, an Evolution Trajectory view with objective, parameter-evolution,
  and parallel-coordinates plots, and an AGPL-compliant About / Source page.
- **HTTP client** (`integration/claude_mem_client.py`) that wraps 9
  claude-mem endpoints with defensive error handling and graceful
  degradation.
- **SSE subscriber** (`integration/sse_subscriber.py`) for real-time
  observation streaming with exponential backoff reconnection.
- **CLI entry points**: `clawmem-benchmark`, `clawmem-evolve`,
  `clawmem-seed-demo-data`.
- **One-shot demo script** (`scripts/demo.sh`) that provisions the venv,
  seeds evolution history, runs benchmark, and starts both backend and
  frontend — useful for presentations.
- **Docker support** via multi-stage `Dockerfile` and `docker-compose.yml` as
  a live-demo fallback.
- **Unit + integration tests** (`pytest`, currently 10 tests) covering
  parameter sanitization, metrics computation, offline benchmark, offline
  evolution loop, and graceful degradation of `memory_compress`.
- **GitHub Actions CI** (`.github/workflows/ci.yml`) running pytest, ruff,
  and the frontend build.
- **Compliance automation** (`scripts/check_compliance.sh`) verifying the
  presence of `LICENSE`, `NOTICE`, dashboard source link, and AGPL headers.

### Documented

- `README.md` — quick start, repository layout, APIs, license.
- `docs/architecture.md` — component map, HTTP boundary, policy internals,
  failure modes, roadmap.
- `docs/api_reference.md` — Skill tools, dashboard REST API, CLI, env vars.
- `docs/compliance.md` — AGPL-3.0 obligations, release checklist, fork
  etiquette.
- `docs/demo_script.md` — 5-minute pitch with fallbacks and Q&A prep.

### Known limitations

- The benchmark dataset uses simulated ground truth; production deployments
  will want to swap in real user signals.
- The policy is global (one θ per deployment); per-agent policies are in the
  roadmap but not implemented.
- Dashboard binds to loopback by default and has no authentication. Put a
  reverse proxy in front of it for any multi-user deployment.
- Live benchmark requires a running claude-mem worker and several minutes to
  execute 30 trials; the default dashboard "Trigger" button uses offline mode
  for interactive snappiness.
