#!/usr/bin/env bash
set -euo pipefail

test -s LICENSE
test -s NOTICE
grep -q "Built On claude-mem" README.md
grep -q "Source Code" dashboard/frontend/src/pages/About.tsx
grep -q "claude-mem" dashboard/frontend/src/pages/About.tsx

missing_py=$(find integration salience policy benchmark dashboard skill scripts tests -name '*.py' -print0 | xargs -0 grep -L "Licensed under AGPL-3.0" || true)
missing_ts=$(find dashboard/frontend/src -name '*.ts' -o -name '*.tsx' | xargs grep -L "Licensed under AGPL-3.0" || true)

if [[ -n "$missing_py" ]]; then
  echo "Missing Python AGPL headers:"
  echo "$missing_py"
  exit 1
fi

if [[ -n "$missing_ts" ]]; then
  echo "Missing TS/TSX AGPL headers:"
  echo "$missing_ts"
  exit 1
fi

echo "Compliance smoke check passed."
