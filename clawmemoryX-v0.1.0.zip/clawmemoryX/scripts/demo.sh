#!/usr/bin/env bash
# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.
#
# One-shot demo script. Runs everything in offline mode so it works without
# the claude-mem worker or any API key. Leaves the dashboard running so a
# presenter can click through Memory Browser + Evolution pages.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

PORT_BACKEND="${CLAWMEM_DASHBOARD_PORT:-8000}"
PORT_FRONTEND="${CLAWMEM_FRONTEND_PORT:-5173}"
BACKEND_PID=""
FRONTEND_PID=""

log() { printf "\033[36m[demo]\033[0m %s\n" "$*"; }
warn() { printf "\033[33m[demo]\033[0m %s\n" "$*" >&2; }
fail() { printf "\033[31m[demo] %s\033[0m\n" "$*" >&2; exit 1; }

cleanup() {
  if [[ -n "$BACKEND_PID" ]] && kill -0 "$BACKEND_PID" 2>/dev/null; then
    log "Stopping backend (pid $BACKEND_PID)"
    kill "$BACKEND_PID" 2>/dev/null || true
  fi
  if [[ -n "$FRONTEND_PID" ]] && kill -0 "$FRONTEND_PID" 2>/dev/null; then
    log "Stopping frontend (pid $FRONTEND_PID)"
    kill "$FRONTEND_PID" 2>/dev/null || true
  fi
}

if [[ "${CLAWMEM_DEMO_KEEP_ALIVE:-1}" == "0" ]]; then
  trap cleanup EXIT INT TERM
fi

# -----------------------------------------------------------------------------
# 1. Python environment
# -----------------------------------------------------------------------------
if [[ ! -d .venv ]]; then
  log "Creating .venv (first run only)"
  python3 -m venv .venv
  # shellcheck disable=SC1091
  source .venv/bin/activate
  python -m pip install --upgrade pip >/dev/null
  pip install -e ".[dashboard,test]" >/dev/null
else
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

# -----------------------------------------------------------------------------
# 2. Seed evolution history so the Evolution page is populated on first load
# -----------------------------------------------------------------------------
log "Seeding demo evolution history"
python -m scripts.seed_demo_data

# -----------------------------------------------------------------------------
# 3. Run 10 offline evolution trials so the best-so-far curve keeps climbing
# -----------------------------------------------------------------------------
log "Running 10 offline evolution trials"
python -m scripts.trigger_evolution --trials 10 --mode offline >/tmp/clawmem_evolve.json
TAIL=$(python -c "
import json, sys
with open('/tmp/clawmem_evolve.json') as f:
    data = json.load(f)
print(f\"best_value={data.get('best_value'):.4f}\" if data.get('best_value') is not None else 'best_value=none')
print(f\"best_params={data.get('best_params')}\")
print(f\"optimizer={data.get('optimizer', 'unknown')}\")
")
log "$TAIL"

# -----------------------------------------------------------------------------
# 4. Quick offline benchmark to print the headline numbers
# -----------------------------------------------------------------------------
log "Running benchmark against the new best params"
python -m scripts.run_benchmark --mode offline --output /tmp/clawmem_benchmark.json >/dev/null
python - <<'PY'
import json
with open('/tmp/clawmem_benchmark.json') as f:
    data = json.load(f)
metrics = data['metrics']
print(f"  recall_at_k:        {metrics['recall_at_k']*100:5.1f}%")
print(f"  task_success_rate:  {metrics['task_success_rate']*100:5.1f}%")
print(f"  token_cost:         {metrics['token_cost']:,}")
print(f"  n_cases:            {metrics['n_cases']}")
print(f"  mode:               {metrics['mode']}")
PY

# -----------------------------------------------------------------------------
# 5. Start backend (and frontend dev server if npm is available)
# -----------------------------------------------------------------------------
log "Starting FastAPI backend on :$PORT_BACKEND"
uvicorn dashboard.backend.main:app --host 127.0.0.1 --port "$PORT_BACKEND" --log-level warning &
BACKEND_PID=$!
sleep 2

if curl -fsS "http://127.0.0.1:$PORT_BACKEND/api/health" >/dev/null; then
  log "Backend healthy: http://127.0.0.1:$PORT_BACKEND/api/health"
else
  fail "Backend did not come up in time"
fi

if command -v npm >/dev/null 2>&1 && [[ -d dashboard/frontend ]]; then
  if [[ ! -d dashboard/frontend/node_modules ]]; then
    log "Installing frontend dependencies (first run only)"
    (cd dashboard/frontend && npm install --silent)
  fi
  log "Starting Vite frontend on :$PORT_FRONTEND"
  (cd dashboard/frontend && npm run dev -- --port "$PORT_FRONTEND" >/tmp/clawmem_frontend.log 2>&1) &
  FRONTEND_PID=$!
  sleep 3
  log "Frontend URL: http://127.0.0.1:$PORT_FRONTEND"
else
  warn "npm not found; skipping frontend. Backend API is available, but UI will not render."
fi

# -----------------------------------------------------------------------------
# 6. Final pointers
# -----------------------------------------------------------------------------
cat <<EOF

==================================================================
  ClawMemory-X demo is live
==================================================================
  Dashboard API    : http://127.0.0.1:$PORT_BACKEND/api/health
  Dashboard UI     : http://127.0.0.1:$PORT_FRONTEND
  Current params   : http://127.0.0.1:$PORT_BACKEND/api/evolution/current
  Evolution history: http://127.0.0.1:$PORT_BACKEND/api/evolution/history
  Benchmark        : http://127.0.0.1:$PORT_BACKEND/api/benchmark/run?mode=offline

  Press Ctrl+C to stop (or export CLAWMEM_DEMO_KEEP_ALIVE=0 to auto-clean).
==================================================================
EOF

if [[ "${CLAWMEM_DEMO_KEEP_ALIVE:-1}" == "1" ]]; then
  wait
fi
