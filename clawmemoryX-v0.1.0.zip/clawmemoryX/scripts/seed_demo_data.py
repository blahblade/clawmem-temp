# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Seed demo evolution history for dashboard fallback screenshots.

Produces 20 trials that tell a coherent story on the dashboard:
  1. first 5 trials are TPE startup (random-ish exploration) with low scores,
  2. trials 5-12 show targeted exploration around `vector_weight ~ 0.58`,
  3. trials 12-19 converge around the best-observed region.

The generated history is deterministic so demo screenshots are reproducible.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

from policy.current import set_current_params
from policy.evolver import HISTORY_PATH
from policy.params import sanitize_params

DEMO_TRIALS = [
    # (stage, params, value, recall, success, token_cost)
    ({"vector_weight": 0.82, "top_k": 6,  "compression_threshold": 12000, "salience_cutoff": 0.42, "episodic_retention": 18}, 0.42, 0.60, 0.55, 18400),
    ({"vector_weight": 0.15, "top_k": 19, "compression_threshold": 3000,  "salience_cutoff": 0.48, "episodic_retention": 82}, 0.38, 0.56, 0.45, 22800),
    ({"vector_weight": 0.95, "top_k": 4,  "compression_threshold": 15000, "salience_cutoff": 0.11, "episodic_retention": 10}, 0.34, 0.52, 0.35, 14300),
    ({"vector_weight": 0.30, "top_k": 15, "compression_threshold": 5000,  "salience_cutoff": 0.20, "episodic_retention": 72}, 0.47, 0.65, 0.55, 19900),
    ({"vector_weight": 0.71, "top_k": 9,  "compression_threshold": 10000, "salience_cutoff": 0.36, "episodic_retention": 24}, 0.50, 0.68, 0.65, 16800),

    ({"vector_weight": 0.63, "top_k": 11, "compression_threshold": 9000,  "salience_cutoff": 0.32, "episodic_retention": 30}, 0.56, 0.73, 0.75, 15500),
    ({"vector_weight": 0.47, "top_k": 13, "compression_threshold": 7000,  "salience_cutoff": 0.27, "episodic_retention": 48}, 0.60, 0.77, 0.80, 14700),
    ({"vector_weight": 0.55, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.30, "episodic_retention": 42}, 0.64, 0.81, 0.85, 13900),
    ({"vector_weight": 0.60, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 45}, 0.67, 0.83, 0.85, 13600),
    ({"vector_weight": 0.52, "top_k": 11, "compression_threshold": 6500,  "salience_cutoff": 0.26, "episodic_retention": 48}, 0.65, 0.82, 0.85, 13700),
    ({"vector_weight": 0.58, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 60}, 0.72, 0.88, 0.90, 13100),
    ({"vector_weight": 0.56, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 55}, 0.70, 0.86, 0.90, 13200),

    ({"vector_weight": 0.58, "top_k": 13, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 60}, 0.73, 0.89, 0.90, 13000),
    ({"vector_weight": 0.57, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.27, "episodic_retention": 58}, 0.73, 0.88, 0.90, 13050),
    ({"vector_weight": 0.59, "top_k": 12, "compression_threshold": 7500,  "salience_cutoff": 0.29, "episodic_retention": 62}, 0.73, 0.89, 0.90, 13040),
    ({"vector_weight": 0.58, "top_k": 11, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 60}, 0.71, 0.87, 0.90, 13100),
    ({"vector_weight": 0.58, "top_k": 12, "compression_threshold": 6800,  "salience_cutoff": 0.28, "episodic_retention": 60}, 0.74, 0.90, 0.95, 12900),
    ({"vector_weight": 0.58, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 60}, 0.74, 0.90, 0.95, 12900),
    ({"vector_weight": 0.58, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 60}, 0.73, 0.89, 0.90, 12950),
    ({"vector_weight": 0.58, "top_k": 12, "compression_threshold": 7000,  "salience_cutoff": 0.28, "episodic_retention": 60}, 0.74, 0.90, 0.95, 12880),
]


def main() -> None:
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    start = datetime.now(UTC) - timedelta(minutes=len(DEMO_TRIALS) * 3)
    with HISTORY_PATH.open("w", encoding="utf-8") as handle:
        best_params = DEMO_TRIALS[0][0]
        best_value = DEMO_TRIALS[0][1]
        for i, (params, value, recall, success, token_cost) in enumerate(DEMO_TRIALS):
            sanitized = sanitize_params(params)
            handle.write(
                json.dumps(
                    {
                        "run_id": "demo-seed",
                        "trial_number": i,
                        "params": sanitized,
                        "value": value,
                        "metrics": {
                            "recall_at_k": recall,
                            "task_success_rate": success,
                            "token_cost": token_cost,
                            "max_token_cost": 750000,
                            "n_cases": 15,
                            "mode": "offline",
                        },
                        "state": "COMPLETE",
                        "datetime": (start + timedelta(minutes=i * 3)).isoformat(),
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )
            if value > best_value:
                best_value = value
                best_params = sanitized
    set_current_params(best_params)
    print(
        f"Seeded {len(DEMO_TRIALS)} demo trials into {HISTORY_PATH}\n"
        f"Best value: {best_value:.4f} with params: {best_params}"
    )


if __name__ == "__main__":
    main()


if __name__ == "__main__":
    main()
