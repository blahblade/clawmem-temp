# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""CLI entry point for running the benchmark."""

from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from benchmark.evaluate import run_benchmark
from policy.current import get_current_params


async def _amain() -> None:
    parser = argparse.ArgumentParser(description="Run ClawMemory-X benchmark")
    parser.add_argument("--mode", choices=["auto", "live", "offline"], default="auto")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()

    metrics = await run_benchmark(get_current_params(), mode=args.mode)
    payload = {"params": get_current_params(), "metrics": metrics}
    text = json.dumps(payload, indent=2, ensure_ascii=False)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)


def main() -> None:
    asyncio.run(_amain())


if __name__ == "__main__":
    main()
