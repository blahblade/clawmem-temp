#!/usr/bin/env bash
set -euo pipefail

curl -fsS http://localhost:8000/api/health >/dev/null
curl -fsS http://localhost:8000/api/evolution/current >/dev/null
if curl -fsS http://localhost:37777/health >/dev/null; then
  echo "claude-mem worker healthy"
else
  echo "claude-mem worker not reachable; offline mode is still available"
fi

echo "ClawMemory-X smoke test passed."
