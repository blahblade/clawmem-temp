# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""CLI entry point for policy evolution."""

from __future__ import annotations

import argparse
import asyncio
import json

from policy.evolver import evolve


async def _amain() -> None:
    parser = argparse.ArgumentParser(description="Trigger ClawMemory-X policy evolution")
    parser.add_argument("--trials", type=int, default=10)
    parser.add_argument("--mode", choices=["auto", "live", "offline"], default="auto")
    parser.add_argument("--no-apply", action="store_true")
    args = parser.parse_args()
    result = await evolve(n_trials=args.trials, apply_best=not args.no_apply, mode=args.mode)
    print(json.dumps(result, indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_amain())


if __name__ == "__main__":
    main()
