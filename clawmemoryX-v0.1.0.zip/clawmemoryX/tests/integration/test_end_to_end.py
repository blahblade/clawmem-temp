# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

import asyncio

from policy.evolver import evolve
from skill.memory_compress import memory_compress


def test_offline_evolution_loop():
    result = asyncio.run(evolve(n_trials=2, apply_best=False, mode="offline"))
    assert result["n_trials"] == 2
    assert result["best_params"]


def test_memory_compress_without_backend():
    # Backend may be unavailable in CI; the tool should return a structured result rather than crash.
    result = asyncio.run(memory_compress([
        {"role": "user", "content": "ok"},
        {"role": "user", "content": "Decision: use FastAPI"},
    ]))
    assert "kept" in result
    assert "compressed" in result
