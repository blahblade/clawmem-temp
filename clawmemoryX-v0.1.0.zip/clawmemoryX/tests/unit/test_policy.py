# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

from pathlib import Path

from policy import current
from policy.params import DEFAULT_PARAMS, PolicyParams, sanitize_params


def test_sanitize_params_clamps_values():
    params = sanitize_params({"top_k": 999, "vector_weight": -1, "compression_threshold": 2300})
    assert params["top_k"] == 20
    assert params["vector_weight"] == 0.0
    assert params["compression_threshold"] == 2000


def test_current_params_roundtrip(tmp_path: Path, monkeypatch):
    monkeypatch.setattr(current, "CURRENT_PATH", tmp_path / "current.json")
    current.set_current_params(DEFAULT_PARAMS)
    assert current.get_current_params()["top_k"] == DEFAULT_PARAMS["top_k"]


def test_policy_params_default():
    assert isinstance(PolicyParams.default().to_dict()["top_k"], int)
