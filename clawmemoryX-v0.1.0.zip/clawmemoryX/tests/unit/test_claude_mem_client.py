# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

import asyncio
import json

import httpx

from integration.claude_mem_client import ClaudeMemClient


def test_client_health_and_search():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/health":
            return httpx.Response(200, json={"ok": True})
        if request.url.path == "/api/search":
            return httpx.Response(200, json={"results": [{"id": 1, "title": "T", "snippet": "S", "score": 0.9}]})
        return httpx.Response(404)

    async def run():
        transport = httpx.MockTransport(handler)
        async with ClaudeMemClient(base_url="http://testserver", transport=transport) as client:
            assert await client.health()
            results = await client.search("test")
            assert results[0].id == "1"
            assert results[0].score == 0.9

    asyncio.run(run())


def test_client_get_observations_fallback():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/observations/batch":
            return httpx.Response(404)
        if request.url.path == "/api/observation/1":
            return httpx.Response(200, content=json.dumps({"id": 1, "content": "hello"}).encode())
        return httpx.Response(404)

    async def run():
        transport = httpx.MockTransport(handler)
        async with ClaudeMemClient(base_url="http://testserver", transport=transport) as client:
            observations = await client.get_observations([1])
            assert observations == [{"id": 1, "content": "hello"}]

    asyncio.run(run())
