# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

import asyncio

from benchmark.evaluate import run_benchmark
from benchmark.metrics import compute_recall, compute_success
from policy.params import DEFAULT_PARAMS


def test_metrics_compute_recall_and_success():
    retrieved = [{"content": "Python FastAPI Amazon Taobao price history"}]
    expected = ["Python", "FastAPI", "Amazon"]
    assert compute_recall(retrieved, expected) == 1.0
    assert compute_success(retrieved, expected) == 1.0


def test_offline_benchmark_runs():
    metrics = asyncio.run(run_benchmark(DEFAULT_PARAMS, mode="offline"))
    assert metrics["n_cases"] == 15
    assert 0 <= metrics["recall_at_k"] <= 1
    assert metrics["token_cost"] > 0
