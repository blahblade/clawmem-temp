# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

import asyncio

from salience import scorer


def test_salience_scores_are_clamped(monkeypatch):
    monkeypatch.setattr(scorer, "DEEPSEEK_API_KEY", "")
    scores = asyncio.run(scorer.score_messages([
        {"role": "user", "content": "We decided to use FastAPI and Chroma."},
        {"role": "assistant", "content": "ok"},
    ]))
    assert len(scores) == 2
    assert all(0 <= score <= 1 for score in scores)
    assert scores[0] > scores[1]
