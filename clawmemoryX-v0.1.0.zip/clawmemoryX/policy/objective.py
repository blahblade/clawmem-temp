# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Objective function for Bayesian policy optimization."""

from __future__ import annotations

from typing import Any

from benchmark.evaluate import run_benchmark


def score_metrics(metrics: dict[str, Any]) -> float:
    recall = float(metrics.get("recall_at_k", 0.0))
    task_success = float(metrics.get("task_success_rate", 0.0))
    token_cost = float(metrics.get("token_cost", 0.0))
    max_token_cost = max(1.0, float(metrics.get("max_token_cost", 1.0)))
    token_cost_ratio = min(1.0, token_cost / max_token_cost)
    return 0.5 * recall + 0.3 * task_success - 0.2 * token_cost_ratio


async def evaluate_objective(params: dict[str, Any], mode: str | None = None) -> tuple[float, dict[str, Any]]:
    metrics = await run_benchmark(params, mode=mode)
    return score_metrics(metrics), metrics


async def objective(params: dict[str, Any], mode: str | None = None) -> float:
    score, _metrics = await evaluate_objective(params, mode=mode)
    return score
