# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Periodic policy evolution scheduler."""

from __future__ import annotations

import asyncio
import logging

from policy.evolver import evolve

logger = logging.getLogger(__name__)


async def periodic_evolve(interval_hours: float = 24, n_trials: int = 10, mode: str | None = None) -> None:
    while True:
        await asyncio.sleep(interval_hours * 3600)
        try:
            await evolve(n_trials=n_trials, mode=mode)
        except Exception as exc:  # pragma: no cover - long-running service path
            logger.warning("periodic evolution skipped: %s", exc)
