# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Optuna-based Bayesian optimization for memory policy parameters.

If Optuna is unavailable, the module falls back to a deterministic random search
so demo mode and CI can still run before dependencies are installed.
"""

from __future__ import annotations

import json
import logging
import os
import random
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

try:  # pragma: no cover - branch depends on environment
    import optuna  # type: ignore
except Exception:  # pragma: no cover
    optuna = None  # type: ignore[assignment]

from policy.current import set_current_params
from policy.objective import evaluate_objective
from policy.params import PARAM_SPACE, sanitize_params

logger = logging.getLogger(__name__)

HISTORY_PATH = Path(os.environ.get("CLAWMEM_HISTORY_PATH", Path(__file__).parent / "data" / "history.jsonl"))


def _suggest_params_optuna(trial: Any) -> dict[str, float | int]:
    params: dict[str, float | int] = {}
    for name, spec in PARAM_SPACE.items():
        if spec["type"] == "float":
            params[name] = trial.suggest_float(name, float(spec["low"]), float(spec["high"]))
        elif spec["type"] == "int":
            params[name] = trial.suggest_int(
                name,
                int(spec["low"]),
                int(spec["high"]),
                step=int(spec.get("step", 1)),
            )
        else:  # pragma: no cover - impossible with current spec
            raise ValueError(f"Unsupported parameter spec: {name}={spec}")
    return sanitize_params(params)


def _suggest_params_random(rng: random.Random) -> dict[str, float | int]:
    params: dict[str, float | int] = {}
    for name, spec in PARAM_SPACE.items():
        if spec["type"] == "float":
            params[name] = rng.uniform(float(spec["low"]), float(spec["high"]))
        else:
            low, high, step = int(spec["low"]), int(spec["high"]), int(spec.get("step", 1))
            choices = list(range(low, high + 1, step))
            params[name] = rng.choice(choices)
    return sanitize_params(params)


async def evolve(n_trials: int = 30, apply_best: bool = True, mode: str | None = None) -> dict[str, Any]:
    """Run optimization and optionally apply the best policy."""

    n_trials = max(1, int(n_trials))
    run_id = f"evolve-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    if optuna is None:
        return await _evolve_random(n_trials=n_trials, apply_best=apply_best, mode=mode, run_id=run_id)
    return await _evolve_optuna(n_trials=n_trials, apply_best=apply_best, mode=mode, run_id=run_id)


async def _evolve_optuna(n_trials: int, apply_best: bool, mode: str | None, run_id: str) -> dict[str, Any]:
    sampler = optuna.samplers.TPESampler(
        seed=int(os.environ.get("CLAWMEM_OPTUNA_SEED", "42")),
        n_startup_trials=min(5, n_trials),
    )
    study = optuna.create_study(direction="maximize", sampler=sampler, study_name=run_id)

    history_rows: list[dict[str, Any]] = []
    for _ in range(n_trials):
        trial = study.ask()
        params = _suggest_params_optuna(trial)
        try:
            value, metrics = await evaluate_objective(params, mode=mode)
            study.tell(trial, value)
            state = "COMPLETE"
        except Exception as exc:  # pragma: no cover - benchmark failures are environment-specific
            logger.exception("evolution trial failed: %s", exc)
            study.tell(trial, state=optuna.trial.TrialState.FAIL)
            value = None
            metrics = {"error": str(exc)}
            state = "FAIL"
        history_rows.append(_history_row(run_id, trial.number, params, value, metrics, state))

    _append_history(history_rows)
    complete_trials = [trial for trial in study.trials if trial.state == optuna.trial.TrialState.COMPLETE]
    if not complete_trials:
        return {"best_params": {}, "best_value": None, "n_trials": len(study.trials), "run_id": run_id}

    best_params = sanitize_params(study.best_trial.params)
    best_value = float(study.best_value)
    if apply_best:
        set_current_params(best_params)

    return {
        "best_params": best_params,
        "best_value": best_value,
        "n_trials": len(study.trials),
        "run_id": run_id,
        "history_path": str(HISTORY_PATH),
        "optimizer": "optuna-tpe",
    }


async def _evolve_random(n_trials: int, apply_best: bool, mode: str | None, run_id: str) -> dict[str, Any]:
    rng = random.Random(int(os.environ.get("CLAWMEM_OPTUNA_SEED", "42")))
    history_rows: list[dict[str, Any]] = []
    best_params: dict[str, float | int] = {}
    best_value: float | None = None

    for trial_number in range(n_trials):
        params = _suggest_params_random(rng)
        try:
            value, metrics = await evaluate_objective(params, mode=mode)
            state = "COMPLETE"
        except Exception as exc:  # pragma: no cover
            logger.exception("random fallback evolution trial failed: %s", exc)
            value = None
            metrics = {"error": str(exc)}
            state = "FAIL"
        history_rows.append(_history_row(run_id, trial_number, params, value, metrics, state))
        if value is not None and (best_value is None or value > best_value):
            best_value = float(value)
            best_params = params

    _append_history(history_rows)
    if best_params and apply_best:
        set_current_params(best_params)

    return {
        "best_params": best_params,
        "best_value": best_value,
        "n_trials": n_trials,
        "run_id": run_id,
        "history_path": str(HISTORY_PATH),
        "optimizer": "random-fallback",
    }


def _history_row(
    run_id: str,
    trial_number: int,
    params: dict[str, float | int],
    value: float | None,
    metrics: dict[str, Any],
    state: str,
) -> dict[str, Any]:
    return {
        "run_id": run_id,
        "trial_number": trial_number,
        "params": params,
        "value": value,
        "metrics": metrics,
        "state": state,
        "datetime": datetime.now(UTC).isoformat(),
    }


def _append_history(rows: list[dict[str, Any]]) -> None:
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    with HISTORY_PATH.open("a", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
