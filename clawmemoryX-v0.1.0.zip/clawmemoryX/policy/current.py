# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Read/write current active memory-policy parameters."""

from __future__ import annotations

import json
import os
from pathlib import Path
from threading import RLock
from typing import Any

from policy.params import DEFAULT_PARAMS, sanitize_params

CURRENT_PATH = Path(os.environ.get("CLAWMEM_POLICY_PATH", Path(__file__).parent / "data" / "current.json"))
_lock = RLock()


def ensure_current_params() -> dict[str, float | int]:
    return get_current_params()


def get_current_params() -> dict[str, float | int]:
    with _lock:
        if not CURRENT_PATH.exists():
            set_current_params(DEFAULT_PARAMS)
            return dict(DEFAULT_PARAMS)
        try:
            data = json.loads(CURRENT_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            data = dict(DEFAULT_PARAMS)
        params = sanitize_params(data)
        if params != data:
            set_current_params(params)
        return params


def set_current_params(params: dict[str, Any]) -> None:
    with _lock:
        sanitized = sanitize_params(params)
        CURRENT_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = CURRENT_PATH.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(sanitized, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        tmp_path.replace(CURRENT_PATH)
