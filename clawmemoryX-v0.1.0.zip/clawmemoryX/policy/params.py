# ClawMemory-X — Self-Evolving Memory for OpenClaw
# Copyright (C) 2026 SJTU ClawMemory-X Team
# Licensed under AGPL-3.0. See LICENSE in the project root.

"""Evolvable memory-policy parameters."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

PARAM_SPACE: dict[str, dict[str, Any]] = {
    "vector_weight": {"low": 0.0, "high": 1.0, "type": "float"},
    "top_k": {"low": 3, "high": 20, "type": "int"},
    "compression_threshold": {"low": 2000, "high": 16000, "type": "int", "step": 1000},
    "salience_cutoff": {"low": 0.1, "high": 0.5, "type": "float"},
    "episodic_retention": {"low": 7, "high": 90, "type": "int"},
}

DEFAULT_PARAMS: dict[str, float | int] = {
    "vector_weight": 0.7,
    "top_k": 10,
    "compression_threshold": 8000,
    "salience_cutoff": 0.3,
    "episodic_retention": 30,
}


@dataclass(slots=True)
class PolicyParams:
    vector_weight: float
    top_k: int
    compression_threshold: int
    salience_cutoff: float
    episodic_retention: int

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PolicyParams:
        sanitized = sanitize_params(data)
        return cls(**sanitized)  # type: ignore[arg-type]

    @classmethod
    def default(cls) -> PolicyParams:
        return cls.from_dict(DEFAULT_PARAMS)


def sanitize_params(params: dict[str, Any] | None = None) -> dict[str, float | int]:
    """Fill missing values and clamp parameters into the declared space."""

    params = params or {}
    output: dict[str, float | int] = {}
    for name, default in DEFAULT_PARAMS.items():
        spec = PARAM_SPACE[name]
        value = params.get(name, default)
        if spec["type"] == "int":
            value = int(round(float(value)))
            step = int(spec.get("step", 1))
            low = int(spec["low"])
            if step > 1:
                value = low + round((value - low) / step) * step
            output[name] = int(max(spec["low"], min(spec["high"], value)))
        else:
            output[name] = float(max(spec["low"], min(spec["high"], float(value))))
    return output
